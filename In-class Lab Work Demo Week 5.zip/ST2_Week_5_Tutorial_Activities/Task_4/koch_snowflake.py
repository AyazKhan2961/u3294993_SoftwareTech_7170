from tkinter import * # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title

        self.width = 260
        self.height = 300
        self.canvas = Canvas(window,
                             width=self.width, height=self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()

        Label(frame1,
              text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order,
              justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")

        p1 = [self.width / 2, 50]
        p2 = [50, self.height - 50]
        p3 = [self.width - 50, self.height - 50]

        self.center = [
            (p1[0] + p2[0] + p3[0]) / 3,
            (p1[1] + p2[1] + p3[1]) / 3
        ]

        self.displayTriangles(int(self.order.get()), p1, p2, p3)

    def displayTriangles(self, order, p1, p2, p3):
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0: # Base condition
            self.drawLine(p1, p2)
        else:
            p12 = [
                p1[0] + (p2[0] - p1[0]) / 3,
                p1[1] + (p2[1] - p1[1]) / 3
            ]
            p23 = [
                p1[0] + 2 * (p2[0] - p1[0]) / 3,
                p1[1] + 2 * (p2[1] - p1[1]) / 3
            ]

            dx = p23[0] - p12[0]
            dy = p23[1] - p12[1]

            peak1 = [
                p12[0] + dx * math.cos(math.radians(60)) - dy * math.sin(math.radians(60)),
                p12[1] + dx * math.sin(math.radians(60)) + dy * math.cos(math.radians(60))
            ]

            peak2 = [
                p12[0] + dx * math.cos(math.radians(-60)) - dy * math.sin(math.radians(-60)),
                p12[1] + dx * math.sin(math.radians(-60)) + dy * math.cos(math.radians(-60))
            ]

            if self.distance(peak1, self.center) > self.distance(peak2, self.center):
                peak = peak1
            else:
                peak = peak2

            self.drawKoch(order - 1, p1, p12)
            self.drawKoch(order - 1, p12, peak)
            self.drawKoch(order - 1, peak, p23)
            self.drawKoch(order - 1, p23, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags="line")

    def distance(self, p1, p2):
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

KochSnowflake() # Create GUI