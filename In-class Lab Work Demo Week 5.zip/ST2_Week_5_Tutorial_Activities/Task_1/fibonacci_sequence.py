# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
import timeit


def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number is {result}")

#Iterative loop of Fibonacci sequence 
def fibonacci_iterative(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
    

# Comparing Iterative vs Recursive implementations for different data sizes.
# Test case
data_size = 30  

print(f"Testing Fibonacci for data size = {data_size}")

# Recursive test
time_recursive = timeit.timeit(lambda: fibonacci(data_size), number=10)
print(f"Recursive time: {time_recursive:.6f} seconds")

# Iterative test
time_iterative = timeit.timeit(lambda: fibonacci_iterative(data_size), number=10)
print(f"Iterative time: {time_iterative:.6f} seconds")