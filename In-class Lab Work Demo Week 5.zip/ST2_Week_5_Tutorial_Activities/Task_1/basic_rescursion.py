import random
import timeit   

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result}")

# iterative loop of recursion
def sum_of_natural_numbers_iterative(n):
    total=0
    for i in range(1,n+1):
        total+=i
    return total

# Comparing Iterative vs Recursive implementations for different data sizes.

# Test case
data_size = 990

print(f"Testing for data size = {data_size}")

# Recursive test
time_recursive = timeit.timeit(lambda: sum_of_natural_numbers(data_size), number=1000)
print(f"Recursive time: {time_recursive:.6f} seconds")

# Iterative test
time_iterative = timeit.timeit(lambda: sum_of_natural_numbers_iterative(data_size), number=1000)
print(f"Iterative time: {time_iterative:.6f} seconds")