# CHALLENGE: Use recursion to calculate the factorial.
import timeit


def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")

#iterative loop of factorial computation
def factorial_iterative(n):
    total=1
    for i in range(1,n+1):
        total*=i
    return total


# Test Case
data_size = 500  

print(f"Testing Factorial for data size = {data_size}")

# Recursive test
time_recursive = timeit.timeit(lambda: factorial(data_size), number=1000)
print(f"Recursive time: {time_recursive:.6f} seconds")

# Iterative test
time_iterative = timeit.timeit(lambda: factorial_iterative(data_size), number=1000)
print(f"Iterative time: {time_iterative:.6f} seconds")