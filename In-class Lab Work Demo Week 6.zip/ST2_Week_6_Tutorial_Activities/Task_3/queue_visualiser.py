import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 20
CANVAS_WIDTH = 800
CANVAS_HEIGHT = 220


# Node class based on linked structure
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None


# Queue class using linked nodes
class Queue:
    def __init__(self):
        self.front = None
        self.rear = None

    def push(self, data):   # push inserts into queue
        new_node = Node(data)

        if self.rear is None:
            self.front = new_node
            self.rear = new_node
        else:
            self.rear.next = new_node
            new_node.prev = self.rear
            self.rear = new_node

    def pop(self):   # pop removes from front of queue
        if self.front is None:
            return None

        removed_value = self.front.data
        self.front = self.front.next

        if self.front is not None:
            self.front.prev = None
        else:
            self.rear = None

        return removed_value

    def is_empty(self):
        return self.front is None

    def to_list(self):
        values = []
        current = self.front
        while current:
            values.append(current.data)
            current = current.next
        return values


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = Queue()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white")
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Value:").grid(row=0, column=0, padx=5)
        self.value_entry = tk.Entry(control_frame, width=10)
        self.value_entry.grid(row=0, column=1, padx=5)

        push_btn = tk.Button(control_frame, text="Push", command=self.push_value, width=10)
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Pop", command=self.pop_value, width=10)
        pop_btn.grid(row=0, column=3, padx=5)

        self.status_label = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.status_label.pack(pady=10)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightblue", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_arrow(self, x1, y1, x2, y2):
        self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST, width=2)

    def draw_queue(self):
        self.canvas.delete("all")
        items = self.queue.to_list()

        if not items:
            return

        x = 50
        y = 90

        for i, value in enumerate(items):
            self.draw_node(x, y, value)

            if i < len(items) - 1:
                self.draw_arrow(
                    x + NODE_WIDTH, y + NODE_HEIGHT / 2,
                    x + NODE_WIDTH + HORIZONTAL_GAP, y + NODE_HEIGHT / 2
                )

            x += NODE_WIDTH + HORIZONTAL_GAP

        first_node_center = 50 + NODE_WIDTH / 2
        last_node_center = 50 + (len(items) - 1) * (NODE_WIDTH + HORIZONTAL_GAP) + NODE_WIDTH / 2

        self.canvas.create_text(first_node_center, 50, text="Front", font=("Arial", 12), fill="red")
        self.canvas.create_text(last_node_center, 50, text="Rear", font=("Arial", 12), fill="red")

    def push_value(self):
        try:
            value = int(self.value_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid integer.")
            return

        self.queue.push(value)
        self.value_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {value} into the queue")
        self.draw_queue()

    def pop_value(self):
        if self.queue.is_empty():
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot pop.")
            return

        removed = self.queue.pop()
        self.status_label.config(text=f"Popped {removed} from the queue")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
        # Example test cases:
    # app.stack = [10, 20, 30]
    # app.draw_stack(
    root.mainloop()