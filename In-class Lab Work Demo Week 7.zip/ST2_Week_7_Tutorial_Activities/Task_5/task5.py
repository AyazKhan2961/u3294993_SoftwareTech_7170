import tkinter as tk
from tkinter import ttk, messagebox
import time
import random
import string
import matplotlib.pyplot as plt


#BST Tree

class BSTNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BSTree:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return BSTNode(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result


#AVL Tree

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        t3 = y.right

        y.right = z
        z.left = t3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left

        y.left = z
        z.right = t2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result


#RBT Red-Black Tree 

class RBNode:
    def __init__(self, name=None, phone=None, color="black"):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode()
        self.root = self.NIL

    def search(self, node, name):
        while node != self.NIL and node.name != name:
            if name < node.name:
                node = node.left
            else:
                node = node.right
        return None if node == self.NIL else node

    def left_rotate(self, x):
        y = x.right
        x.right = y.left

        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent

        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right

        if x.right != self.NIL:
            x.right.parent = y

        x.parent = y.parent

        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, name, phone):
        existing = self.search(self.root, name)
        if existing:
            existing.phone = phone
            return

        node = RBNode(name, phone, "red")
        node.left = self.NIL
        node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if node.name < current.name:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node

        if node.parent is None:
            node.color = "black"
            return

        if node.parent.parent is None:
            return

        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == "red":
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == "red":
                    u.color = "black"
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == "red":
                    u.color = "black"
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.right_rotate(k.parent.parent)

            if k == self.root:
                break

        self.root.color = "black"

    def transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z is None:
            return

        y = z
        y_original_color = y.color

        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right

            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y

            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == "black":
            self.fix_delete(x)

    def fix_delete(self, x):
        while x != self.root and x.color == "black":
            if x == x.parent.left:
                s = x.parent.right

                if s.color == "red":
                    s.color = "black"
                    x.parent.color = "red"
                    self.left_rotate(x.parent)
                    s = x.parent.right

                if s.left.color == "black" and s.right.color == "black":
                    s.color = "red"
                    x = x.parent
                else:
                    if s.right.color == "black":
                        s.left.color = "black"
                        s.color = "red"
                        self.right_rotate(s)
                        s = x.parent.right

                    s.color = x.parent.color
                    x.parent.color = "black"
                    s.right.color = "black"
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                s = x.parent.left

                if s.color == "red":
                    s.color = "black"
                    x.parent.color = "red"
                    self.right_rotate(x.parent)
                    s = x.parent.left

                if s.right.color == "black" and s.left.color == "black":
                    s.color = "red"
                    x = x.parent
                else:
                    if s.left.color == "black":
                        s.right.color = "black"
                        s.color = "red"
                        self.left_rotate(s)
                        s = x.parent.left

                    s.color = x.parent.color
                    x.parent.color = "black"
                    s.left.color = "black"
                    self.right_rotate(x.parent)
                    x = self.root

        x.color = "black"

    def inorder(self, node=None, result=None):
        if result is None:
            result = []

        if node is None:
            node = self.root

        if node != self.NIL:
            self.inorder(node.left, result)
            result.append((node.name, node.phone, node.color))
            self.inorder(node.right, result)

        return result


#bencharking

def generate_contacts(n):
    names = []
    used = set()

    while len(names) < n:
        name = ''.join(random.choices(string.ascii_lowercase, k=7))
        if name not in used:
            used.add(name)
            names.append(name)

    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    return names, phones


def benchmark_once(n=1000):
    names, phones = generate_contacts(n)

    bst = BSTree()
    avl = AVLTree()
    rbt = RedBlackTree()

    search_names = random.sample(names, n // 2) + ['zzzzzzz'] * (n // 2)
    delete_names = random.sample(names, min(100, n))

    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert = time.time() - start

    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert = time.time() - start

    start = time.time()
    for i in range(n):
        rbt.insert(names[i], phones[i])
    rbt_insert = time.time() - start

    start = time.time()
    found_bst = 0
    for name in search_names:
        if bst.search(bst.root, name):
            found_bst += 1
    bst_search = time.time() - start

    start = time.time()
    found_avl = 0
    for name in search_names:
        if avl.search(avl.root, name):
            found_avl += 1
    avl_search = time.time() - start

    start = time.time()
    found_rbt = 0
    for name in search_names:
        if rbt.search(rbt.root, name):
            found_rbt += 1
    rbt_search = time.time() - start

    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete = time.time() - start

    start = time.time()
    for name in delete_names:
        rbt.delete(name)
    rbt_delete = time.time() - start

    return {
        "Insertions": (bst_insert, avl_insert, rbt_insert),
        "Searches": (bst_search, avl_search, rbt_search),
        "Deletions": (bst_delete, avl_delete, rbt_delete),
        "Found In Search": (found_bst, found_avl, found_rbt)
    }


def run_benchmark_for_sizes(sizes):
    bst_times = {"insert": [], "search": [], "delete": []}
    avl_times = {"insert": [], "search": [], "delete": []}
    rbt_times = {"insert": [], "search": [], "delete": []}

    for n in sizes:
        results = benchmark_once(n)

        bst_times["insert"].append(results["Insertions"][0])
        avl_times["insert"].append(results["Insertions"][1])
        rbt_times["insert"].append(results["Insertions"][2])

        bst_times["search"].append(results["Searches"][0])
        avl_times["search"].append(results["Searches"][1])
        rbt_times["search"].append(results["Searches"][2])

        bst_times["delete"].append(results["Deletions"][0])
        avl_times["delete"].append(results["Deletions"][1])
        rbt_times["delete"].append(results["Deletions"][2])

    plt.figure(figsize=(12, 8))

    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times["insert"], label="BST Insert")
    plt.plot(sizes, avl_times["insert"], label="AVL Insert")
    plt.plot(sizes, rbt_times["insert"], label="RBT Insert")
    plt.ylabel("Time (seconds)")
    plt.title("Insertion Time vs Input Size")
    plt.legend()

    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times["search"], label="BST Search")
    plt.plot(sizes, avl_times["search"], label="AVL Search")
    plt.plot(sizes, rbt_times["search"], label="RBT Search")
    plt.ylabel("Time (seconds)")
    plt.title("Search Time vs Input Size")
    plt.legend()

    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times["delete"], label="BST Delete")
    plt.plot(sizes, avl_times["delete"], label="AVL Delete")
    plt.plot(sizes, rbt_times["delete"], label="RBT Delete")
    plt.xlabel("Number of Nodes")
    plt.ylabel("Time (seconds)")
    plt.title("Deletion Time vs Input Size")
    plt.legend()

    plt.tight_layout()
    plt.show(block=False)


# === Tkinter GUI App ===

class TreeApp:
    def __init__(self, master):
        self.master = master
        self.master.title("BST vs AVL vs Red-Black Tree")

        self.bst = BSTree()
        self.avl = AVLTree()
        self.rbt = RedBlackTree()

        self.tree_type = tk.StringVar(value="RBT")

        input_frame = tk.Frame(master)
        input_frame.pack(pady=10)

        tk.Label(input_frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(input_frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(input_frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(input_frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        tk.Label(input_frame, text="Tree Type:").grid(row=0, column=2, padx=5)
        self.tree_menu = ttk.Combobox(
            input_frame,
            textvariable=self.tree_type,
            values=["BST", "AVL", "RBT"],
            state="readonly",
            width=10
        )
        self.tree_menu.grid(row=0, column=3, padx=5)

        button_frame = tk.Frame(master)
        button_frame.pack(pady=5)

        tk.Button(button_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(button_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(button_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(button_frame, text="Run Benchmark", command=self.run_benchmark).grid(row=0, column=4, padx=5)
        tk.Button(button_frame, text="Plot Sizes", command=self.plot_sizes).grid(row=0, column=5, padx=5)

        self.output_text = tk.Text(master, height=12, width=80)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=1000, height=450, bg="white")
        self.canvas.pack(pady=10)

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return

        tree = self.tree_type.get()

        if tree == "BST":
            self.bst.root = self.bst.insert(self.bst.root, name, phone)
        elif tree == "AVL":
            self.avl.root = self.avl.insert(self.avl.root, name, phone)
        else:
            self.rbt.insert(name, phone)

        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return

        tree = self.tree_type.get()

        if tree == "BST":
            node = self.bst.search(self.bst.root, name)
        elif tree == "AVL":
            node = self.avl.search(self.avl.root, name)
        else:
            node = self.rbt.search(self.rbt.root, name)

        self.output_text.delete(1.0, tk.END)

        if node:
            if tree == "RBT":
                self.output_text.insert(
                    tk.END,
                    f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\nColor: {node.color}\n"
                )
            else:
                self.output_text.insert(
                    tk.END,
                    f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n"
                )
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to delete.")
            return

        tree = self.tree_type.get()

        if tree == "BST":
            self.bst.root = self.bst.delete(self.bst.root, name)
        elif tree == "AVL":
            self.avl.root = self.avl.delete(self.avl.root, name)
        else:
            self.rbt.delete(name)

        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        tree = self.tree_type.get()

        if tree == "BST":
            contacts = self.bst.inorder(self.bst.root)
            if not contacts:
                self.output_text.insert(tk.END, "No contacts found.\n")
            else:
                for name, phone in contacts:
                    self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}\n")

        elif tree == "AVL":
            contacts = self.avl.inorder(self.avl.root)
            if not contacts:
                self.output_text.insert(tk.END, "No contacts found.\n")
            else:
                for name, phone in contacts:
                    self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}\n")

        else:
            contacts = self.rbt.inorder()
            if not contacts:
                self.output_text.insert(tk.END, "No contacts found.\n")
            else:
                for name, phone, color in contacts:
                    self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}, Color: {color}\n")

    def draw_tree(self):
        self.canvas.delete("all")
        tree = self.tree_type.get()

        if tree == "BST" and self.bst.root:
            self._draw_normal_node(self.bst.root, 500, 30, 220)

        elif tree == "AVL" and self.avl.root:
            self._draw_normal_node(self.avl.root, 500, 30, 220)

        elif tree == "RBT" and self.rbt.root != self.rbt.NIL:
            self._draw_rb_node(self.rbt.root, 500, 30, 220)

    def _draw_normal_node(self, node, x, y, x_offset):
        if node is None:
            return

        radius = 22

        if node.left:
            xl = x - x_offset
            yl = y + 70
            self.canvas.create_line(x, y + radius, xl, yl - radius)
            self._draw_normal_node(node.left, xl, yl, max(40, x_offset // 2))

        if node.right:
            xr = x + x_offset
            yr = y + 70
            self.canvas.create_line(x, y + radius, xr, yr - radius)
            self._draw_normal_node(node.right, xr, yr, max(40, x_offset // 2))

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill="lightblue")
        label = node.name if len(node.name) <= 8 else node.name[:8]
        self.canvas.create_text(x, y, text=label)

    def _draw_rb_node(self, node, x, y, x_offset):
        if node == self.rbt.NIL:
            return

        radius = 22

        if node.left != self.rbt.NIL:
            xl = x - x_offset
            yl = y + 70
            self.canvas.create_line(x, y + radius, xl, yl - radius)
            self._draw_rb_node(node.left, xl, yl, max(40, x_offset // 2))

        if node.right != self.rbt.NIL:
            xr = x + x_offset
            yr = y + 70
            self.canvas.create_line(x, y + radius, xr, yr - radius)
            self._draw_rb_node(node.right, xr, yr, max(40, x_offset // 2))

        fill_color = "red" if node.color == "red" else "black"
        text_color = "white"

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color)
        label = node.name if len(node.name) <= 8 else node.name[:8]
        self.canvas.create_text(x, y, text=label, fill=text_color)

    def run_benchmark(self):
        self.output_text.delete(1.0, tk.END)
        results = benchmark_once(1000)

        summary = (
            f"Insertions:\n"
            f"BST: {results['Insertions'][0]:.6f}s\n"
            f"AVL: {results['Insertions'][1]:.6f}s\n"
            f"RBT: {results['Insertions'][2]:.6f}s\n\n"
            f"Searches:\n"
            f"BST: {results['Searches'][0]:.6f}s\n"
            f"AVL: {results['Searches'][1]:.6f}s\n"
            f"RBT: {results['Searches'][2]:.6f}s\n\n"
            f"Deletions:\n"
            f"BST: {results['Deletions'][0]:.6f}s\n"
            f"AVL: {results['Deletions'][1]:.6f}s\n"
            f"RBT: {results['Deletions'][2]:.6f}s\n\n"
            f"Found in search:\n"
            f"BST: {results['Found In Search'][0]}\n"
            f"AVL: {results['Found In Search'][1]}\n"
            f"RBT: {results['Found In Search'][2]}\n"
        )

        self.output_text.insert(tk.END, summary)

    def plot_sizes(self):
        run_benchmark_for_sizes([100, 200, 400, 800, 1600, 3200, 5000, 10000])


if __name__ == "__main__":
    root = tk.Tk()
    app = TreeApp(root)
    root.mainloop()