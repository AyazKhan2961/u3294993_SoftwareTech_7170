import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.linked_list import SinglyLinkedList


class TestLinkedList(unittest.TestCase):

    def test_insert_at_index(self):
        """Insert node with value 10 at position 2 — node present in correct location."""
        ll = SinglyLinkedList()
        ll.insert_at_end(5)
        ll.insert_at_end(15)
        ll.insert_at_end(20)
        ll.insert_at_index(10, 2)
        result = ll.to_list()
        self.assertEqual(result[2], 10)

    def test_insert_at_head(self):
        ll = SinglyLinkedList()
        ll.insert_at_end(10)
        ll.insert_at_end(20)
        ll.insert_at_index(5, 0)
        self.assertEqual(ll.to_list()[0], 5)

    def test_delete_value(self):
        ll = SinglyLinkedList()
        for v in [10, 20, 30]:
            ll.insert_at_end(v)
        self.assertTrue(ll.delete_value(20))
        self.assertNotIn(20, ll.to_list())

    def test_delete_not_found(self):
        ll = SinglyLinkedList()
        ll.insert_at_end(5)
        self.assertFalse(ll.delete_value(99))

    def test_reverse(self):
        ll = SinglyLinkedList()
        for v in [1, 2, 3, 4]:
            ll.insert_at_end(v)
        ll.reverse()
        self.assertEqual(ll.to_list(), [4, 3, 2, 1])

    def test_search(self):
        ll = SinglyLinkedList()
        for v in [10, 20, 30]:
            ll.insert_at_end(v)
        self.assertTrue(ll.search(20))
        self.assertFalse(ll.search(99))


if __name__ == "__main__":
    unittest.main()
