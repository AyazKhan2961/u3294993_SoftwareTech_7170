import unittest
import time
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.stack import Stack


class TestStack(unittest.TestCase):

    def test_push_pop_sequence(self):
        """Push 3 items, pop 2 — final stack size = 1, correct order."""
        s = Stack()
        s.push(10)
        s.push(20)
        s.push(30)
        self.assertEqual(s.size(), 3)
        self.assertEqual(s.pop(), 30)
        self.assertEqual(s.pop(), 20)
        self.assertEqual(s.size(), 1)
        self.assertEqual(s.peek(), 10)

    def test_push_pop_large(self):
        """Push 1000 items, pop all — correct LIFO order."""
        s = Stack()
        for i in range(1000):
            s.push(i)
        self.assertEqual(s.size(), 1000)
        for i in reversed(range(1000)):
            self.assertEqual(s.pop(), i)
        self.assertTrue(s.is_empty())

    def test_peek_and_exceptions(self):
        """Peek and exceptions on empty stack."""
        s = Stack()
        with self.assertRaises(IndexError):
            s.pop()
        with self.assertRaises(IndexError):
            s.peek()
        s.push(42)
        self.assertEqual(s.peek(), 42)
        self.assertEqual(s.size(), 1)

    def test_is_empty(self):
        s = Stack()
        self.assertTrue(s.is_empty())
        s.push(1)
        self.assertFalse(s.is_empty())
        s.pop()
        self.assertTrue(s.is_empty())

    def test_benchmark(self):
        """Benchmark push/pop 1,000,000 items."""
        s = Stack()
        n = 10 ** 6
        start = time.time()
        for i in range(n):
            s.push(i)
        for i in range(n):
            s.pop()
        elapsed = time.time() - start
        print(f"\nBenchmark Stack push/pop {n} items: {elapsed:.4f} seconds")
        self.assertTrue(s.is_empty())


if __name__ == "__main__":
    unittest.main()
