import unittest
import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


def bubble_sort(arr):
    arr = arr[:]
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr


def selection_sort(arr):
    arr = arr[:]
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr


def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)


def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i]); i += 1
        else:
            result.append(right[j]); j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result


class TestSorting(unittest.TestCase):

    def test_bubble_sort_correctness(self):
        """Sort array of [5,3,8,1,2] — sorted: [1,2,3,5,8]."""
        result = bubble_sort([5, 3, 8, 1, 2])
        self.assertEqual(result, [1, 2, 3, 5, 8])

    def test_selection_sort_correctness(self):
        result = selection_sort([5, 3, 8, 1, 2])
        self.assertEqual(result, [1, 2, 3, 5, 8])

    def test_merge_sort_correctness(self):
        result = merge_sort([5, 3, 8, 1, 2])
        self.assertEqual(result, [1, 2, 3, 5, 8])

    def test_already_sorted(self):
        arr = [1, 2, 3, 4, 5]
        self.assertEqual(bubble_sort(arr), arr)
        self.assertEqual(selection_sort(arr), arr)
        self.assertEqual(merge_sort(arr), arr)

    def test_single_element(self):
        self.assertEqual(bubble_sort([42]), [42])
        self.assertEqual(selection_sort([42]), [42])
        self.assertEqual(merge_sort([42]), [42])

    def test_random_array(self):
        arr = [random.randint(1, 1000) for _ in range(100)]
        expected = sorted(arr)
        self.assertEqual(bubble_sort(arr), expected)
        self.assertEqual(selection_sort(arr), expected)
        self.assertEqual(merge_sort(arr), expected)


if __name__ == "__main__":
    unittest.main()
