import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.bst import BST


class TestBST(unittest.TestCase):

    def test_insert_and_inorder(self):
        #Insert [50, 30, 70]; inorder traversal order: 30, 50, 70.
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        inorder_vals = [n.value for n in bst.inorder()]
        self.assertEqual(inorder_vals, [30, 50, 70])

    def test_search_found(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        result = bst.search(30)
        self.assertIsNotNone(result)
        self.assertEqual(result.value, 30)

    def test_search_not_found(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        result = bst.search(99)
        self.assertIsNone(result)

    def test_preorder(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        preorder_vals = [n.value for n in bst.preorder()]
        self.assertEqual(preorder_vals, [50, 30, 70])

    def test_postorder(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        postorder_vals = [n.value for n in bst.postorder()]
        self.assertEqual(postorder_vals, [30, 70, 50])

    def test_delete(self):
        bst = BST()
        for v in [50, 30, 70, 20, 40]:
            bst.insert(v)
        bst.delete(30)
        inorder_vals = [n.value for n in bst.inorder()]
        self.assertNotIn(30, inorder_vals)
        self.assertIn(20, inorder_vals)
        self.assertIn(40, inorder_vals)


if __name__ == "__main__":
    unittest.main()
