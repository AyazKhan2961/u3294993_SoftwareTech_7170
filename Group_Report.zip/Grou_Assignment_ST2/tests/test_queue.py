import unittest
import time
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.queue_ds import Queue


class TestQueue(unittest.TestCase):

    def test_enqueue_dequeue_fifo(self):
        #Enqueue 4 items nad dequeue 3 
        q = Queue()
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        q.enqueue(4)
        self.assertEqual(q.size(), 4)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.dequeue(), 2)
        self.assertEqual(q.dequeue(), 3)
        self.assertEqual(q.size(), 1)
        self.assertEqual(q.peek(), 4)

    def test_large_enqueue_dequeue(self):
        #Enqueue 1000 items 
        for i in range(1000):
            q.enqueue(i)
        self.assertEqual(q.size(), 1000)
        for i in range(1000):
            self.assertEqual(q.dequeue(), i)
        self.assertTrue(q.is_empty())

    def test_peek_and_exceptions(self):
        #Peek and exceptions on empty queue.
        q = Queue()
        with self.assertRaises(IndexError):
            q.dequeue()
        with self.assertRaises(IndexError):
            q.peek()
        q.enqueue(99)
        self.assertEqual(q.peek(), 99)

    def test_is_empty(self):
        q = Queue()
        self.assertTrue(q.is_empty())
        q.enqueue(5)
        self.assertFalse(q.is_empty())
        q.dequeue()
        self.assertTrue(q.is_empty())

    def test_benchmark(self):
        """Benchmark enqueue/dequeue 1,000,000 items."""
        q = Queue()
        n = 10 ** 6
        start = time.time()
        for i in range(n):
            q.enqueue(i)
        for i in range(n):
            q.dequeue()
        elapsed = time.time() - start
        print(f"\nBenchmark Queue enqueue/dequeue {n} items: {elapsed:.4f} seconds")
        self.assertTrue(q.is_empty())


if __name__ == "__main__":
    unittest.main()
