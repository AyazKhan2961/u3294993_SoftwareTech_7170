import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from modules.graph import Graph


class TestGraph(unittest.TestCase):

    def setUp(self):
        self.g = Graph()
        for v in ['A', 'B', 'C', 'D', 'E', 'F']:
            self.g.add_vertex(v)
        self.g.add_edge('A', 'B')
        self.g.add_edge('A', 'C')
        self.g.add_edge('B', 'D')
        self.g.add_edge('B', 'E')
        self.g.add_edge('C', 'F')

    def test_bfs_from_a(self):
        
        visited = self.g.bfs('A')
        # A must be first
        self.assertEqual(visited[0], 'A')
        # All nodes reachable
        self.assertEqual(set(visited), {'A', 'B', 'C', 'D', 'E', 'F'})
        # B and C before D, E, F
        self.assertLess(visited.index('B'), visited.index('D'))
        self.assertLess(visited.index('C'), visited.index('F'))

    def test_dfs_from_a(self):
        #DFS from 'A' visits all nodes.
        visited = self.g.dfs('A')
        self.assertEqual(visited[0], 'A')
        self.assertEqual(set(visited), {'A', 'B', 'C', 'D', 'E', 'F'})

    def test_cycle_detection_with_cycle(self):
        cycle_g = Graph(directed=False)
        for v in ['A', 'B', 'C']:
            cycle_g.add_vertex(v)
        cycle_g.add_edge('A', 'B')
        cycle_g.add_edge('B', 'C')
        cycle_g.add_edge('C', 'A')
        self.assertTrue(cycle_g.has_undirected_cycle())

    def test_cycle_detection_no_cycle(self):
        acyclic = Graph(directed=False)
        for v in ['X', 'Y', 'Z']:
            acyclic.add_vertex(v)
        acyclic.add_edge('X', 'Y')
        acyclic.add_edge('Y', 'Z')
        self.assertFalse(acyclic.has_undirected_cycle())

    def test_add_remove_vertex_edge(self):
        g = Graph()
        g.add_vertex('A')
        g.add_vertex('B')
        g.add_vertex('C')
        g.add_edge('A', 'B')
        g.add_edge('B', 'C')
        g.remove_edge('A', 'B')
        self.assertNotIn('B', g.graph['A'])
        g.remove_vertex('C')
        self.assertNotIn('C', g.graph)


if __name__ == "__main__":
    unittest.main()
