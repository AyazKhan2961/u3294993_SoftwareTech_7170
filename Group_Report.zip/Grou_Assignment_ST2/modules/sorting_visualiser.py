# Reference: Weekly labs &  https://github.com/nas-programmer/sorting_visualization
import pygame
import sys
import random
import unittest


WIDTH, HEIGHT = 600, 400
ARRAY_SIZE = 30
clock = pygame.time.Clock()



def draw_array(screen, array, color_positions=None):
    screen.fill((30, 30, 30))
    bar_width = WIDTH // len(array)
    for i, val in enumerate(array):
        color = (100, 200, 250)
        if color_positions and i in color_positions.get('compare', []):
            color = (255, 100, 100)
        if color_positions and i in color_positions.get('swap', []):
            color = (100, 255, 100)
        if color_positions and i in color_positions.get('sorted', []):
            color = (150, 150, 150)
        pygame.draw.rect(screen, color,
                         (i * bar_width, HEIGHT - val, bar_width - 2, val))
    pygame.display.flip()


def bubble_sort_visualize(screen, array):
    n = len(array)
    for i in range(n):
        for j in range(0, n - i - 1):
            draw_array(screen, array, {'compare': [j, j + 1], 'swap': []})
            pygame.time.wait(50)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            if array[j] > array[j + 1]:
                array[j], array[j + 1] = array[j + 1], array[j]
                draw_array(screen, array, {'compare': [], 'swap': [j, j + 1]})
                pygame.time.wait(50)
    draw_array(screen, array)



def selection_sort_visualize(screen, array):
    n = len(array)
    sorted_indices = []
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            draw_array(screen, array,
                       {'compare': [j, min_idx], 'swap': [], 'sorted': sorted_indices})
            pygame.time.wait(30)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            if array[j] < array[min_idx]:
                min_idx = j
        if min_idx != i:
            array[i], array[min_idx] = array[min_idx], array[i]
            draw_array(screen, array,
                       {'compare': [], 'swap': [i, min_idx], 'sorted': sorted_indices})
            pygame.time.wait(40)
        sorted_indices.append(i)
    draw_array(screen, array, {'sorted': list(range(n))})



def merge_sort_visualize(screen, array):
    def merge(arr, l, m, r):
        left = arr[l:m + 1]
        right = arr[m + 1:r + 1]
        i = j = 0
        k = l
        while i < len(left) and j < len(right):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            draw_array(screen, arr, {'compare': [k], 'swap': []})
            pygame.time.wait(30)
            if left[i] <= right[j]:
                arr[k] = left[i]
                i += 1
            else:
                arr[k] = right[j]
                j += 1
            k += 1
        while i < len(left):
            arr[k] = left[i]
            i += 1
            k += 1
        while j < len(right):
            arr[k] = right[j]
            j += 1
            k += 1

    def merge_sort(arr, l, r):
        if l < r:
            m = (l + r) // 2
            merge_sort(arr, l, m)
            merge_sort(arr, m + 1, r)
            merge(arr, l, m, r)

    merge_sort(array, 0, len(array) - 1)
    draw_array(screen, array, {'sorted': list(range(len(array)))})


def bubble_sort_bars(screen):
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    W, H = 640, 480
    n = 4
    w = int(W / n)
    h_arr = []
    states = []
    for i in range(w):
        height = random.randint(10, 450)
        h_arr.append(height)
        states.append(1)
    counter = 0
    running = True
    while running:
        screen.fill(BLACK)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
        if counter < len(h_arr):
            for j in range(len(h_arr) - 1 - counter):
                if h_arr[j] > h_arr[j + 1]:
                    states[j] = 0
                    states[j + 1] = 0
                    temp = h_arr[j]
                    h_arr[j] = h_arr[j + 1]
                    h_arr[j + 1] = temp
                else:
                    states[j] = 1
                    states[j + 1] = 1
        counter += 1
        if len(h_arr) - counter >= 0:
            states[len(h_arr) - counter] = 2
        for i in range(len(h_arr)):
            if states[i] == 0:
                color = (255, 0, 0)
            elif states[i] == 2:
                color = (0, 255, 0)
            else:
                color = WHITE
            pygame.draw.rect(screen, color,
                             pygame.Rect(int(i * n), H - h_arr[i], n, h_arr[i]))
        clock.tick(20)
        pygame.display.flip()


def insertion_sort_bars(screen):
    W, H = 640, 480
    n = 4
    w = int(W / n)
    h_arr = []
    for i in range(w):
        h_arr.append(random.randint(10, 450))
    counter = 0
    running = True
    while running:
        screen.fill((10, 10, 10))
        if counter < len(h_arr):
            key = h_arr[counter]
            j = counter - 1
            while j >= 0 and key < h_arr[j]:
                h_arr[j + 1] = h_arr[j]
                j -= 1
            h_arr[j + 1] = key
        else:
            pass
        counter += 1
        for i in range(len(h_arr)):
            pygame.draw.rect(screen, (255, 255, 255),
                             (i * n, H - h_arr[i], n, h_arr[i]))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
        clock.tick(60)
        pygame.display.flip()



def selection_sort_bars(screen):
    import pygame as pg
    from pygame.locals import QUIT, KEYDOWN, K_ESCAPE
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    W, H = 640, 480
    n = 4
    w = int(W / n)
    h_arr = []
    state = []
    for i in range(w):
        height = random.randint(10, 450)
        h_arr.append(height)
        state.append(1)
    counter = 0
    running = True
    while running:
        screen.fill((10, 10, 10))
        if counter < len(h_arr):
            min_idx = counter
            for j in range(counter + 1, len(h_arr)):
                if h_arr[min_idx] > h_arr[j]:
                    state[j] = 0
                    min_idx = j
                else:
                    state[j] = 1
                    state[min_idx] = 1
            h_arr[counter], h_arr[min_idx] = h_arr[min_idx], h_arr[counter]
        counter += 1
        if counter - 1 < len(h_arr):
            state[counter - 1] = 2
        for i in range(len(h_arr)):
            if state[i] == 0:
                color = RED
            elif state[i] == 2:
                color = GREEN
            else:
                color = WHITE
            pg.draw.rect(screen, color,
                         pg.Rect(int(i * n), H - h_arr[i], n, h_arr[i]))
        for event in pg.event.get():
            if event.type == QUIT:
                pg.quit()
                sys.exit()
            if event.type == KEYDOWN and event.key == K_ESCAPE:
                running = False
        clock.tick(30)
        pg.display.flip()



def quick_sort_bars(screen):
    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    W, H = 720, 400
    n = 4
    w = int(W / n)
    h_arr = []
    state = []
    for i in range(w):
        height = random.randint(0, 400)
        h_arr.append(height)
        state.append(1)

    def maps(num, in_min, in_max, out_min, out_max):
        return (num - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

    def partition(arr, start, end):
        for i in range(start, end):
            state[i] = 0
        i = start
        pivot = arr[end]
        state[start] = 0
        for j in range(start, end):
            if arr[j] < pivot:
                arr[i], arr[j] = arr[j], arr[i]
                state[i] += 1
                i += 1
                state[i] = 0
        arr[i], arr[end] = arr[end], arr[i]
        return i

    end = len(h_arr) - 1
    start = 0
    size = end - start + 1
    stack = [0] * size
    top = 0
    stack[top] = 0
    top += 1
    stack[top] = end
    j = 0
    flag = False
    running = True
    while running:
        screen.fill((10, 10, 10))
        if flag:
            if top >= 0:
                end = stack[top]
                top -= 1
                start = stack[top]
                top -= 1
                p = partition(h_arr, start, end)
                state[p] = 1
                if p - 1 > start:
                    top += 1
                    stack[top] = start
                    top += 1
                    stack[top] = p - 1
                if p + 1 < end:
                    top += 1
                    stack[top] = p + 1
                    top += 1
                    stack[top] = end
            else:
                if j < len(h_arr):
                    state[j] = 2
                    j += 1
        for i in range(len(h_arr)):
            h_ar = maps(h_arr[i], 0, 400, 20, 255)
            pygame.draw.rect(screen, (h_ar // 3, h_ar, h_ar // 4),
                             pygame.Rect(int(i * n), (H - h_arr[i]) // 2, n, h_arr[i]))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    flag = True
                if event.key == pygame.K_ESCAPE:
                    running = False
        clock.tick(60)
        pygame.display.flip()



def sorting_visualization(screen, font):
    array = [random.randint(10, 350) for _ in range(ARRAY_SIZE)]
    running = True
    info_font = pygame.font.SysFont(None, 24)

    btn_bubble   = pygame.Rect(10,  HEIGHT - 80, 100, 40)
    btn_select   = pygame.Rect(120, HEIGHT - 80, 120, 40)
    btn_merge    = pygame.Rect(250, HEIGHT - 80, 100, 40)
    btn_reset    = pygame.Rect(360, HEIGHT - 80, 90,  40)
    btn_bsort2   = pygame.Rect(460, HEIGHT - 80, 115, 40)
    btn_insert2  = pygame.Rect(10,  HEIGHT - 35, 120, 30)
    btn_select2  = pygame.Rect(140, HEIGHT - 35, 120, 30)
    btn_quick    = pygame.Rect(270, HEIGHT - 35, 120, 30)

    def draw_buttons():
        for btn, label, col in [
            (btn_bubble,  "Bubble",       (80, 120, 200)),
            (btn_select,  "Selection",    (80, 180, 120)),
            (btn_merge,   "Merge",        (180, 100, 180)),
            (btn_reset,   "Reset",        (120, 120, 120)),
            (btn_bsort2,  "Bubble Bars",  (60, 100, 160)),
            (btn_insert2, "Insert Bars",  (60, 140, 100)),
            (btn_select2, "Select Bars",  (140, 80, 80)),
            (btn_quick,   "Quick Bars",   (140, 100, 60)),
        ]:
            pygame.draw.rect(screen, col, btn)
            t = info_font.render(label, True, (255, 255, 255))
            screen.blit(t, (btn.x + btn.width // 2 - t.get_width() // 2,
                             btn.y + btn.height // 2 - t.get_height() // 2))

    while running:
        draw_array(screen, array)
        draw_buttons()
        hint = info_font.render("ESC: back to menu", True, (180, 180, 180))
        screen.blit(hint, (10, 10))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                arr_copy = array[:]
                if btn_bubble.collidepoint(pos):
                    bubble_sort_visualize(screen, arr_copy)
                    array = arr_copy
                elif btn_select.collidepoint(pos):
                    selection_sort_visualize(screen, arr_copy)
                    array = arr_copy
                elif btn_merge.collidepoint(pos):
                    merge_sort_visualize(screen, arr_copy)
                    array = arr_copy
                elif btn_reset.collidepoint(pos):
                    array = [random.randint(10, 350) for _ in range(ARRAY_SIZE)]
                elif btn_bsort2.collidepoint(pos):
                    bubble_sort_bars(screen)
                elif btn_insert2.collidepoint(pos):
                    insertion_sort_bars(screen)
                elif btn_select2.collidepoint(pos):
                    selection_sort_bars(screen)
                elif btn_quick.collidepoint(pos):
                    quick_sort_bars(screen)

        clock.tick(30)


def run(screen):
    font = pygame.font.SysFont(None, 28)
    sorting_visualization(screen, font)



def _bubble_sort(arr):
    arr = arr[:]
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr


def _selection_sort(arr):
    arr = arr[:]
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr


def _merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = _merge_sort(arr[:mid])
    right = _merge_sort(arr[mid:])
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


class TestSorting(unittest.TestCase):
    

    def test_bubble_sort_correctness(self):
        #Sort array of [5,3,8,1,2] is Sorted array: [1,2,3,5,8]
        self.assertEqual(_bubble_sort([5, 3, 8, 1, 2]), [1, 2, 3, 5, 8])

    def test_selection_sort_correctness(self):
        self.assertEqual(_selection_sort([5, 3, 8, 1, 2]), [1, 2, 3, 5, 8])

    def test_merge_sort_correctness(self):
        self.assertEqual(_merge_sort([5, 3, 8, 1, 2]), [1, 2, 3, 5, 8])

    def test_already_sorted(self):
        arr = [1, 2, 3, 4, 5]
        self.assertEqual(_bubble_sort(arr), arr)
        self.assertEqual(_selection_sort(arr), arr)
        self.assertEqual(_merge_sort(arr), arr)

    def test_single_element(self):
        self.assertEqual(_bubble_sort([42]), [42])
        self.assertEqual(_selection_sort([42]), [42])
        self.assertEqual(_merge_sort([42]), [42])

    def test_random_array(self):
        arr = [random.randint(1, 1000) for _ in range(100)]
        expected = sorted(arr)
        self.assertEqual(_bubble_sort(arr), expected)
        self.assertEqual(_selection_sort(arr), expected)
        self.assertEqual(_merge_sort(arr), expected)


if __name__ == "__main__":
    unittest.main()
