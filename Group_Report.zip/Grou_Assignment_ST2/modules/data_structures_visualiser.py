import pygame
import sys
from modules.stack import Stack

WIDTH, HEIGHT = 800, 600
clock = pygame.time.Clock()
BLOCK_WIDTH, BLOCK_HEIGHT = 200, 40
START_X = (WIDTH - BLOCK_WIDTH) // 2
BASE_Y = HEIGHT - BLOCK_HEIGHT - 20



def stack_visualization(screen, font):
    stack = Stack()
    counter = 1
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    stack.push(counter)
                    counter += 1
                elif event.key == pygame.K_BACKSPACE and not stack.is_empty():
                    stack.pop()
                elif event.key == pygame.K_ESCAPE:
                    running = False

        screen.fill((50, 50, 50))
        for i, val in enumerate(stack._data):
            rect = pygame.Rect(START_X, BASE_Y - i * (BLOCK_HEIGHT + 5),
                               BLOCK_WIDTH, BLOCK_HEIGHT)
            pygame.draw.rect(screen, (100, 150, 250), rect)
            text = font.render(str(val), True, (0, 0, 0))
            text_rect = text.get_rect(center=rect.center)
            screen.blit(text, text_rect)
        info_text = font.render("SPACE: Push, BACKSPACE: Pop, ESC: Return to menu",
                                True, (200, 200, 200))
        screen.blit(info_text, (10, 10))
        pygame.display.flip()
        clock.tick(30)



from collections import deque as _deque


class Queue:
    def __init__(self):
        self._data = _deque()

    def enqueue(self, val):
        self._data.append(val)

    def dequeue(self):
        if not self.is_empty():
            return self._data.popleft()
        raise IndexError("dequeue from empty queue")

    def peek(self):
        if not self.is_empty():
            return self._data[0]
        raise IndexError("peek from empty queue")

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)


def queue_visualization(screen, font):
    queue = Queue()
    counter = 1
    running = True

    QBLOCK_W = 80
    QBLOCK_H = 50
    btn_enqueue = pygame.Rect(100, HEIGHT - 70, 180, 45)
    btn_dequeue = pygame.Rect(320, HEIGHT - 70, 180, 45)

    def draw_state(offset=0):
        screen.fill((50, 50, 50))
        info = font.render("Queue Visualiser  |  ESC: Return to menu", True, (200, 200, 200))
        screen.blit(info, (10, 10))

        items = list(queue._data)
        start_x = 40 + int(offset)
        y = HEIGHT // 2 - QBLOCK_H // 2

        for i, val in enumerate(items):
            x = start_x + i * (QBLOCK_W + 10)
            color = (250, 150, 80) if i == 0 else (100, 150, 250)
            pygame.draw.rect(screen, color, (x, y, QBLOCK_W, QBLOCK_H))
            txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(txt, (x + QBLOCK_W // 2 - txt.get_width() // 2,
                               y + QBLOCK_H // 2 - txt.get_height() // 2))

        if items:
            screen.blit(font.render("FRONT", True, (255, 100, 100)), (start_x, y - 24))
            rx = start_x + (len(items) - 1) * (QBLOCK_W + 10)
            screen.blit(font.render("REAR", True, (100, 255, 100)), (rx, y - 24))

        pygame.draw.rect(screen, (80, 160, 80), btn_enqueue)
        pygame.draw.rect(screen, (160, 80, 80), btn_dequeue)
        screen.blit(font.render("Enqueue", True, (255, 255, 255)),
                    (btn_enqueue.x + 30, btn_enqueue.y + 10))
        screen.blit(font.render("Dequeue", True, (255, 255, 255)),
                    (btn_dequeue.x + 30, btn_dequeue.y + 10))
        screen.blit(font.render(f"Size: {queue.size()}", True, (220, 220, 220)), (10, 45))
        pygame.display.flip()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                if btn_enqueue.collidepoint(pos):
                    queue.enqueue(counter)
                    counter += 1
                    # Slide-in animation
                    for step in range(10, 0, -1):
                        draw_state(offset=-(QBLOCK_W + 10) * step / 10)
                        pygame.time.wait(20)
                elif btn_dequeue.collidepoint(pos):
                    if not queue.is_empty():
                        queue.dequeue()
                        # Slide-out animation
                        for step in range(0, 10):
                            draw_state(offset=(QBLOCK_W + 10) * step / 10)
                            pygame.time.wait(20)
        draw_state()
        clock.tick(30)



class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):
        if not self.head:
            self.head = Node(value)
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = Node(value)

    def delete(self, value):
        current = self.head
        prev = None
        while current:
            if current.value == value:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next
        return False

    def to_list(self):
        elems = []
        current = self.head
        while current:
            elems.append(current.value)
            current = current.next
        return elems

    def insert_at_position(self, value, pos):
        new_node = Node(value)
        if pos == 0:
            new_node.next = self.head
            self.head = new_node
            return
        current = self.head
        count = 0
        while current and count < pos - 1:
            current = current.next
            count += 1
        if current:
            new_node.next = current.next
            current.next = new_node

    def reverse(self):
        prev = None
        current = self.head
        while current:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev


NODE_RADIUS = 25


def draw_node(screen, font, x, y, value, highlight=False):
    color = (255, 100, 100) if highlight else (100, 200, 250)
    pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
    text = font.render(str(value), True, (0, 0, 0))
    text_rect = text.get_rect(center=(x, y))
    screen.blit(text, text_rect)


def draw_arrow(screen, start_pos, end_pos):
    pygame.draw.line(screen, (0, 0, 0), start_pos, end_pos, 3)
    arrow_head = [
        (end_pos[0] - 10, end_pos[1] - 5),
        end_pos,
        (end_pos[0] - 10, end_pos[1] + 5),
    ]
    pygame.draw.polygon(screen, (0, 0, 0), arrow_head)


def draw_linked_list(screen, font, linked_list, highlight_index=None):
    screen.fill((240, 240, 240))
    nodes = []
    current = linked_list.head
    x, y = 80, HEIGHT // 2
    idx = 0
    while current:
        nodes.append((x, y, current.value, idx == highlight_index))
        x += 150
        current = current.next
        idx += 1
    for i, (x, y, val, highlight) in enumerate(nodes):
        draw_node(screen, font, x, y, val, highlight)
        if i < len(nodes) - 1:
            draw_arrow(screen, (x + NODE_RADIUS, y), (x + 150 - NODE_RADIUS, y))
    pygame.display.flip()


def linked_list_visualization(screen, font):
    ll = LinkedList()
    # Pre-populate as in task_2_1.py main()
    actions = [
        ('append', 5),
        ('append', 10),
        ('append', 15),
        ('delete', 10),
        ('append', 20)
    ]
    for action, value in actions:
        if action == 'append':
            ll.append(value)
        elif action == 'delete':
            ll.delete(value)

    running = True
    input_str = ""
    pos_str = ""
    mode = "append"
    info_font = pygame.font.SysFont(None, 22)

    while running:
        draw_linked_list(screen, font, ll)
        hint = info_font.render(
            "A:append  I:insert-at-pos  D:delete  R:reverse  Type+ENTER  ESC:menu",
            True, (60, 60, 60))
        screen.blit(hint, (10, 10))
        inp = info_font.render(
            f"Mode:{mode}  Value:{input_str}  Pos:{pos_str}",
            True, (60, 60, 180))
        screen.blit(inp, (10, 35))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_a:
                    mode = "append"
                    input_str = ""
                    pos_str = ""
                elif event.key == pygame.K_i:
                    mode = "insert"
                    input_str = ""
                    pos_str = ""
                elif event.key == pygame.K_d:
                    mode = "delete"
                    input_str = ""
                    pos_str = ""
                elif event.key == pygame.K_r:
                    for i in range(len(ll.to_list())):
                        draw_linked_list(screen, font, ll, highlight_index=i)
                        pygame.time.wait(300)
                        for e in pygame.event.get():
                            pass
                    ll.reverse()
                    for i in range(len(ll.to_list())):
                        draw_linked_list(screen, font, ll, highlight_index=i)
                        pygame.time.wait(300)
                        for e in pygame.event.get():
                            pass
                elif event.key == pygame.K_BACKSPACE:
                    if pos_str:
                        pos_str = pos_str[:-1]
                    elif input_str:
                        input_str = input_str[:-1]
                elif event.key == pygame.K_RETURN:
                    if mode == "append" and input_str.lstrip('-').isdigit():
                        ll.append(int(input_str))
                        input_str = ""
                    elif mode == "insert" and input_str.lstrip('-').isdigit() and pos_str.isdigit():
                        ll.insert_at_position(int(input_str), int(pos_str))
                        input_str = ""
                        pos_str = ""
                    elif mode == "delete" and input_str.lstrip('-').isdigit():
                        ll.delete(int(input_str))
                        input_str = ""
                elif event.key == pygame.K_SLASH and mode == "insert":
                    # '/' switches to position input
                    pos_str = ""
                elif event.unicode.isdigit():
                    if mode == "insert" and len(input_str) > 0:
                        pos_str += event.unicode
                    else:
                        input_str += event.unicode
                elif event.unicode == '-' and not input_str:
                    input_str = '-'

        clock.tick(30)



class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, value):
        def _insert(node, value):
            if not node:
                return BSTNode(value)
            if value < node.value:
                node.left = _insert(node.left, value)
            elif value > node.value:
                node.right = _insert(node.right, value)
            return node
        self.root = _insert(self.root, value)

    def inorder(self):
        result = []
        def _inorder(node):
            if node:
                _inorder(node.left)
                result.append(node)
                _inorder(node.right)
        _inorder(self.root)
        return result

    def preorder(self):
        result = []
        def _preorder(node):
            if node:
                result.append(node)
                _preorder(node.left)
                _preorder(node.right)
        _preorder(self.root)
        return result

    def postorder(self):
        result = []
        def _postorder(node):
            if node:
                _postorder(node.left)
                _postorder(node.right)
                result.append(node)
        _postorder(self.root)
        return result

    def search_path(self, value):
        path = []
        current = self.root
        while current:
            path.append(current)
            if value == current.value:
                break
            elif value < current.value:
                current = current.left
            else:
                current = current.right
        return path

    def delete(self, value):
        def find_min(node):
            current = node
            while current.left:
                current = current.left
            return current

        def _delete(node, value):
            if node is None:
                return node
            if value < node.value:
                node.left = _delete(node.left, value)
            elif value > node.value:
                node.right = _delete(node.right, value)
            else:
                # 0 or 1 child
                if node.left is None:
                    return node.right
                elif node.right is None:
                    return node.left
                # 2 children: replace with inorder successor
                temp = find_min(node.right)
                node.value = temp.value
                node.right = _delete(node.right, temp.value)
            return node
        self.root = _delete(self.root, value)


NODE_RADIUS_BST = 20


def draw_bst_node(screen, font, x, y, value, highlight=False):
    color = (255, 150, 150) if highlight else (100, 200, 250)
    pygame.draw.circle(screen, color, (x, y), NODE_RADIUS_BST)
    text = font.render(str(value), True, (0, 0, 0))
    text_rect = text.get_rect(center=(x, y))
    screen.blit(text, text_rect)


def draw_edge(screen, start_pos, end_pos):
    pygame.draw.line(screen, (0, 0, 0), start_pos, end_pos, 3)


def store_positions(node, x, y, x_offset, nodes_pos, parent_pos=None):
    if node:
        nodes_pos[node] = (x, y)
        store_positions(node.left, x - x_offset, y + 80, x_offset // 2, nodes_pos, (x, y))
        store_positions(node.right, x + x_offset, y + 80, x_offset // 2, nodes_pos, (x, y))


def draw_tree(screen, font, bst, highlight_nodes=None):
    screen.fill((240, 240, 240))
    nodes_pos = {}
    store_positions(bst.root, WIDTH // 2, 50, 150, nodes_pos)

    for node, (x, y) in nodes_pos.items():
        if node.left and node.left in nodes_pos:
            draw_edge(screen, (x, y), nodes_pos[node.left])
        if node.right and node.right in nodes_pos:
            draw_edge(screen, (x, y), nodes_pos[node.right])

    for node, (x, y) in nodes_pos.items():
        hl = highlight_nodes and node in highlight_nodes
        draw_bst_node(screen, font, x, y, node.value, hl)

    pygame.display.flip()
    return nodes_pos


def bst_visualization(screen, font):
    bst = BST()
    # Pre-populate as in task_2_2.py
    values = [50, 30, 70, 20, 40, 60, 80]
    for v in values:
        bst.insert(v)

    running = True
    highlight_idx = 0
    traversal_nodes = bst.inorder()
    traversal_label = "Inorder"
    input_str = ""
    info_font = pygame.font.SysFont(None, 22)

    while running:
        nodes_pos = {}
        store_positions(bst.root, WIDTH // 2, 50, 150, nodes_pos)

        highlight = set()
        if traversal_nodes and highlight_idx < len(traversal_nodes):
            highlight.add(traversal_nodes[highlight_idx])

        draw_tree(screen, font, bst, highlight)

        hint = info_font.render(
            "I:inorder  P:preorder  O:postorder  s<n>+ENTER:search  del<n>+ENTER:delete  <n>+ENTER:insert  ESC:menu",
            True, (60, 60, 60))
        screen.blit(hint, (10, 10))
        order_str = " -> ".join(str(n.value) for n in traversal_nodes[:highlight_idx + 1])
        screen.blit(info_font.render(f"{traversal_label}: {order_str}", True, (80, 80, 180)), (10, 32))
        screen.blit(info_font.render(f"Input: {input_str}", True, (60, 60, 100)), (10, 54))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_i:
                    traversal_nodes = bst.inorder()
                    traversal_label = "Inorder"
                    highlight_idx = 0
                elif event.key == pygame.K_p:
                    traversal_nodes = bst.preorder()
                    traversal_label = "Preorder"
                    highlight_idx = 0
                elif event.key == pygame.K_o:
                    traversal_nodes = bst.postorder()
                    traversal_label = "Postorder"
                    highlight_idx = 0
                elif event.key == pygame.K_BACKSPACE:
                    input_str = input_str[:-1]
                elif event.key == pygame.K_RETURN:
                    if input_str.startswith('s') and input_str[1:].lstrip('-').isdigit():
                        path = bst.search_path(int(input_str[1:]))
                        for step in range(len(path)):
                            draw_tree(screen, font, bst, set(path[:step + 1]))
                            pygame.time.wait(500)
                            for e in pygame.event.get():
                                pass
                        input_str = ""
                    elif input_str.lower().startswith('del') and input_str[3:].lstrip('-').isdigit():
                        bst.delete(int(input_str[3:]))
                        traversal_nodes = bst.inorder()
                        highlight_idx = 0
                        input_str = ""
                    elif input_str.lstrip('-').isdigit():
                        bst.insert(int(input_str))
                        traversal_nodes = bst.inorder()
                        highlight_idx = 0
                        input_str = ""
                else:
                    if event.unicode and (event.unicode.isdigit() or
                                          event.unicode == '-' or
                                          event.unicode.lower() in ('s', 'd', 'e', 'l')):
                        input_str += event.unicode

        # 1 frame per second as in task_2_2.py
        clock.tick(1)
        if traversal_nodes:
            highlight_idx = (highlight_idx + 1) % max(len(traversal_nodes), 1)



def run(screen):
    font = pygame.font.SysFont(None, 28)
    menu_items = [
        "Stack Visualization (press enter)",
        "Queue Visualization (press enter)",
        "Linked List Visualization (press enter)",
        "BST Visualization (press enter)",
        "Back"
    ]
    selected = 0
    running = True
    while running:
        screen.fill((220, 220, 220))
        for i, item in enumerate(menu_items):
            color = (255, 0, 0) if i == selected else (0, 0, 0)
            text = font.render(item, True, color)
            screen.blit(text, (100, 100 + i * 40))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    choice = menu_items[selected]
                    if choice == "Stack Visualization (press enter)":
                        stack_visualization(screen, font)
                    elif choice == "Queue Visualization (press enter)":
                        queue_visualization(screen, font)
                    elif choice == "Linked List Visualization (press enter)":
                        linked_list_visualization(screen, font)
                    elif choice == "BST Visualization (press enter)":
                        bst_visualization(screen, font)
                    elif choice == "Back":
                        running = False
        clock.tick(30)



import unittest
import time as _time


class TestDataStructures(unittest.TestCase):

    def test_stack_push_pop_sequence(self):
        #Push 3 items, pop 2 — Final stack size = 1, correct order
        s = Stack()
        s.push(10)
        s.push(20)
        s.push(30)
        self.assertEqual(s.size(), 3)
        self.assertEqual(s.pop(), 30)
        self.assertEqual(s.pop(), 20)
        self.assertEqual(s.size(), 1)

    def test_queue_enqueue_dequeue(self):
        #Enqueue 4 items and dequeue 3 — FIFO order maintained
        q = Queue()
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        q.enqueue(4)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.dequeue(), 2)
        self.assertEqual(q.dequeue(), 3)
        self.assertEqual(q.size(), 1)

    def test_linked_list_insertion_at_pos(self):
        #Insert node with value 10 at position 2 
        ll = LinkedList()
        ll.append(5)
        ll.append(15)
        ll.append(20)
        ll.insert_at_position(10, 2)
        result = ll.to_list()
        self.assertEqual(result[2], 10)

    def test_linked_list_reverse(self):
        ll = LinkedList()
        for v in [1, 2, 3, 4]:
            ll.append(v)
        ll.reverse()
        self.assertEqual(ll.to_list(), [4, 3, 2, 1])

    def test_bst_insert_and_inorder(self):
        #Insert [50,30,70]; inorder traversal — Traversal order: 30, 50, 70
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        self.assertEqual([n.value for n in bst.inorder()], [30, 50, 70])

    def test_bst_preorder(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        self.assertEqual([n.value for n in bst.preorder()], [50, 30, 70])

    def test_bst_postorder(self):
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        self.assertEqual([n.value for n in bst.postorder()], [30, 70, 50])

    def test_bst_delete(self):
        bst = BST()
        for v in [50, 30, 70, 20, 40]:
            bst.insert(v)
        bst.delete(30)
        vals = [n.value for n in bst.inorder()]
        self.assertNotIn(30, vals)
        self.assertIn(20, vals)
        self.assertIn(40, vals)

    def test_stack_benchmark(self):
        s = Stack()
        n = 10**6
        start = _time.time()
        for i in range(n):
            s.push(i)
        for i in range(n):
            s.pop()
        elapsed = _time.time() - start
        print(f"\nStack Benchmark push/pop {n} items: {elapsed:.4f} seconds")

    def test_queue_benchmark(self):
        q = Queue()
        n = 10**6
        start = _time.time()
        for i in range(n):
            q.enqueue(i)
        for i in range(n):
            q.dequeue()
        elapsed = _time.time() - start
        print(f"\nQueue Benchmark enqueue/dequeue {n} items: {elapsed:.4f} seconds")


if __name__ == "__main__":
    unittest.main()
