# Reference: Week 12 &  https://github.com/nas-programmer/path-finding/blob/master/djikstra.py

import pygame
import sys
import collections
import math
import unittest

WIDTH, HEIGHT = 800, 600
clock = pygame.time.Clock()


nodes_pos = {
    'A': (100, 100),
    'B': (250, 60),
    'C': (250, 200),
    'D': (400, 100),
    'E': (500, 150),
    'F': (400, 300)
}

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

NODE_R = 25



def draw_graph(screen, font, visited=None, frontier=None, current=None,
               traversal_order=None, start_vertex='A'):
    if visited is None:
        visited = set()
    if frontier is None:
        frontier = set()

    screen.fill((240, 240, 240))

    # Draw edges
    for node, neighbors in graph.items():
        x1, y1 = nodes_pos[node]
        for n in neighbors:
            x2, y2 = nodes_pos[n]
            pygame.draw.line(screen, (0, 0, 0), (x1, y1), (x2, y2), 2)

    # Draw nodes
    for node, (x, y) in nodes_pos.items():
        color = (200, 200, 200)
        if node in visited:
            color = (100, 200, 100)
        if node in frontier:
            color = (255, 200, 100)
        if node == current:
            color = (255, 100, 100)
        # highlight start vertex
        if node == start_vertex:
            pygame.draw.circle(screen, (50, 50, 200), (x, y), NODE_R + 4)
        pygame.draw.circle(screen, color, (x, y), NODE_R)
        text = font.render(node, True, (0, 0, 0))
        text_rect = text.get_rect(center=(x, y))
        screen.blit(text, text_rect)

    # display traversal order on screen
    if traversal_order:
        info_font = pygame.font.SysFont(None, 24)
        order_str = " -> ".join(traversal_order)
        o = info_font.render(f"Traversal order: {order_str}", True, (50, 50, 150))
        screen.blit(o, (10, HEIGHT - 55))

    info_font = pygame.font.SysFont(None, 22)
    hint = info_font.render(
        f"B:BFS  D:DFS  Click node to set start (current:{start_vertex})  "
        f"P:BFS pathfinding  J:Dijkstra  ESC:menu",
        True, (80, 80, 80))
    screen.blit(hint, (10, HEIGHT - 28))
    pygame.display.flip()



def bfs_traversal(screen, font, start, traversal_order_ref, start_vertex_ref):
    visited = set()
    queue = collections.deque([start])
    traversal_order_ref.clear()
    while queue:
        current = queue.popleft()
        visited.add(current)
        traversal_order_ref.append(current)
        draw_graph(screen, font,
                   visited=visited,
                   frontier=set(queue),
                   current=current,
                   traversal_order=list(traversal_order_ref),
                   start_vertex=start_vertex_ref[0])
        pygame.time.wait(700)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return
        for neighbor in graph[current]:
            if neighbor not in visited and neighbor not in queue:
                queue.append(neighbor)



def dfs_traversal(screen, font, start, traversal_order_ref, start_vertex_ref):
    visited = set()
    stack = [start]
    traversal_order_ref.clear()
    while stack:
        current = stack.pop()
        if current not in visited:
            visited.add(current)
            traversal_order_ref.append(current)
            draw_graph(screen, font,
                       visited=visited,
                       frontier=set(stack),
                       current=current,
                       traversal_order=list(traversal_order_ref),
                       start_vertex=start_vertex_ref[0])
            pygame.time.wait(700)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            for neighbor in reversed(graph[current]):
                if neighbor not in visited:
                    stack.append(neighbor)



def bfs_pathfinding(screen):
    
    W, H = 640, 480
    cols_p, rows_p = 64, 48
    w = W // cols_p
    h = H // rows_p

    grid_p = []
    queue_p = collections.deque()
    visited_p = []
    path_p = []

    class Spot:
        def __init__(self, i, j):
            self.x, self.y = i, j
            self.neighbors = []
            self.prev = None
            self.wall = False
            self.visited = False

        def show(self, win, col):
            if self.wall:
                col = (0, 0, 0)
            pygame.draw.rect(win, col, (self.x * w, self.y * h, w - 1, h - 1))

        def add_neighbors(self, g):
            if self.x < cols_p - 1:
                self.neighbors.append(g[self.x + 1][self.y])
            if self.x > 0:
                self.neighbors.append(g[self.x - 1][self.y])
            if self.y < rows_p - 1:
                self.neighbors.append(g[self.x][self.y + 1])
            if self.y > 0:
                self.neighbors.append(g[self.x][self.y - 1])

    for i in range(cols_p):
        arr = []
        for j in range(rows_p):
            arr.append(Spot(i, j))
        grid_p.append(arr)

    for i in range(cols_p):
        for j in range(rows_p):
            grid_p[i][j].add_neighbors(grid_p)

    start_p = grid_p[cols_p // 2][rows_p // 2]
    end_p = grid_p[cols_p - 1][rows_p - cols_p // 2]
    start_p.wall = False
    end_p.wall = False
    queue_p.append(start_p)
    start_p.visited = True

    flag = False
    noflag = True
    startflag = False

    def clickWall(pos, state):
        i = pos[0] // w
        j = pos[1] // h
        if 0 <= i < cols_p and 0 <= j < rows_p:
            grid_p[i][j].wall = state

    running = True
    info_font = pygame.font.SysFont(None, 22)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    startflag = True
                if event.key == pygame.K_ESCAPE:
                    running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button in (1, 3):
                    clickWall(pygame.mouse.get_pos(), event.button == 1)
            if event.type == pygame.MOUSEMOTION:
                if event.buttons[0] or event.buttons[2]:
                    clickWall(pygame.mouse.get_pos(), event.buttons[0])

        if startflag:
            if len(queue_p) > 0:
                current_p = queue_p.popleft()
                if current_p == end_p:
                    temp = current_p
                    while temp.prev:
                        path_p.append(temp.prev)
                        temp = temp.prev
                    if not flag:
                        flag = True
                    elif flag:
                        pass
                if not flag:
                    for i in current_p.neighbors:
                        if not i.visited and not i.wall:
                            i.visited = True
                            i.prev = current_p
                            queue_p.append(i)
            else:
                if noflag and not flag:
                    noflag = False

        screen.fill((0, 20, 20))
        for i in range(cols_p):
            for j in range(rows_p):
                spot = grid_p[i][j]
                spot.show(screen, (255, 255, 255))
                if spot in path_p:
                    spot.show(screen, (25, 120, 250))
                elif spot.visited:
                    spot.show(screen, (255, 0, 0))
                if spot in queue_p:
                    spot.show(screen, (0, 255, 0))
                if spot == end_p:
                    spot.show(screen, (0, 120, 255))

        hint = info_font.render(
            "Click:wall  ENTER:start  ESC:back", True, (200, 200, 200))
        screen.blit(hint, (10, 10))
        pygame.display.flip()
        clock.tick(30)



def dijkstra_pathfinding(screen):
    #Dijkstra pathfinding 
    W, H = 640, 480
    cols_d, rows_d = 64, 48
    w = W // cols_d
    h = H // rows_d

    grid_d = []
    queue_d = collections.deque()
    path_d = []

    class SpotD:
        def __init__(self, i, j):
            self.x, self.y = i, j
            self.neighbors = []
            self.prev = None
            self.wall = False
            self.visited = False
            if (i + j) % 7 == 0:
                self.wall = False

        def show(self, win, col, shape=1):
            if self.wall:
                col = (0, 0, 0)
            if shape == 1:
                pygame.draw.rect(win, col, (self.x * w, self.y * h, w - 1, h - 1))
            else:
                pygame.draw.circle(win, col,
                                   (self.x * w + w // 2, self.y * h + h // 2), w // 3)

        def add_neighbors(self, g):
            if self.x < cols_d - 1:
                self.neighbors.append(g[self.x + 1][self.y])
            if self.x > 0:
                self.neighbors.append(g[self.x - 1][self.y])
            if self.y < rows_d - 1:
                self.neighbors.append(g[self.x][self.y + 1])
            if self.y > 0:
                self.neighbors.append(g[self.x][self.y - 1])

    for i in range(cols_d):
        arr = []
        for j in range(rows_d):
            arr.append(SpotD(i, j))
        grid_d.append(arr)

    for i in range(cols_d):
        for j in range(rows_d):
            grid_d[i][j].add_neighbors(grid_d)

    start_d = grid_d[0][0]
    end_d = grid_d[cols_d - cols_d // 2][rows_d - cols_d // 4]
    start_d.wall = False
    end_d.wall = False
    queue_d.append(start_d)
    start_d.visited = True

    flag = False
    noflag = True
    startflag = False

    def clickWall(pos, state):
        i = pos[0] // w
        j = pos[1] // h
        if 0 <= i < cols_d and 0 <= j < rows_d:
            grid_d[i][j].wall = state

    running = True
    info_font = pygame.font.SysFont(None, 22)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    startflag = True
                if event.key == pygame.K_ESCAPE:
                    running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button in (1, 3):
                    clickWall(pygame.mouse.get_pos(), event.button == 1)
            if event.type == pygame.MOUSEMOTION:
                if event.buttons[0] or event.buttons[2]:
                    clickWall(pygame.mouse.get_pos(), event.buttons[0])

        if startflag:
            if len(queue_d) > 0:
                current_d = queue_d.popleft()
                if current_d == end_d:
                    temp = current_d
                    while temp.prev:
                        path_d.append(temp.prev)
                        temp = temp.prev
                    if not flag:
                        flag = True
                    elif flag:
                        pass
                if not flag:
                    for i in current_d.neighbors:
                        if not i.visited and not i.wall:
                            i.visited = True
                            i.prev = current_d
                            queue_d.append(i)
            else:
                if noflag and not flag:
                    noflag = False

        screen.fill((0, 20, 20))
        for i in range(cols_d):
            for j in range(rows_d):
                spot = grid_d[i][j]
                spot.show(screen, (44, 62, 80))
                if spot in path_d:
                    spot.show(screen, (46, 204, 113))
                    spot.show(screen, (192, 57, 43), 0)
                elif spot.visited:
                    spot.show(screen, (39, 174, 96))
                if spot in queue_d and not flag:
                    spot.show(screen, (44, 62, 80))
                    spot.show(screen, (39, 174, 96), 0)
                if spot == start_d:
                    spot.show(screen, (0, 255, 200))
                if spot == end_d:
                    spot.show(screen, (0, 120, 255))

        hint = info_font.render(
            "Click:wall  ENTER:start  ESC:back", True, (200, 200, 200))
        screen.blit(hint, (10, 10))
        pygame.display.flip()
        clock.tick(30)



def run(screen):
    font = pygame.font.SysFont(None, 28)
    running = True
    traversal_order = []
    start_vertex = ['A']

    draw_graph(screen, font, start_vertex=start_vertex[0])
    pygame.time.wait(1000)

    while running:
        draw_graph(screen, font,
                   traversal_order=traversal_order if traversal_order else None,
                   start_vertex=start_vertex[0])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_b:
                    bfs_traversal(screen, font, start_vertex[0],
                                  traversal_order, start_vertex)
                elif event.key == pygame.K_d:
                    dfs_traversal(screen, font, start_vertex[0],
                                  traversal_order, start_vertex)
                elif event.key == pygame.K_p:
                    bfs_pathfinding(screen)
                elif event.key == pygame.K_j:
                    dijkstra_pathfinding(screen)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # click node to set as start vertex
                pos = event.pos
                for node, (nx, ny) in nodes_pos.items():
                    dx, dy = pos[0] - nx, pos[1] - ny
                    if math.sqrt(dx * dx + dy * dy) <= NODE_R:
                        start_vertex[0] = node
                        traversal_order.clear()
                        break

        clock.tick(30)




class SimpleGraph:
    
    def __init__(self, adj):
        self.adj = adj

    def bfs(self, start):
        visited = []
        queue = collections.deque([start])
        seen = {start}
        while queue:
            v = queue.popleft()
            visited.append(v)
            for nbr in self.adj[v]:
                if nbr not in seen:
                    seen.add(nbr)
                    queue.append(nbr)
        return visited

    def dfs(self, start):
        visited = []
        stack = [start]
        seen = set()
        while stack:
            v = stack.pop()
            if v not in seen:
                seen.add(v)
                visited.append(v)
                for nbr in reversed(self.adj[v]):
                    if nbr not in seen:
                        stack.append(nbr)
        return visited


class TestGraphTraversal(unittest.TestCase):
    #Module 3: Graph Traversal Test Plan

    def setUp(self):
        self.g = SimpleGraph(graph)

    def test_bfs_from_A(self):
        #Visit nodes reachable from A — Nodes visited in correct BFS order
        visited = self.g.bfs('A')
        self.assertEqual(visited[0], 'A')
        self.assertEqual(set(visited), set(graph.keys()))
        self.assertLess(visited.index('B'), visited.index('D'))
        self.assertLess(visited.index('C'), visited.index('F'))

    def test_dfs_from_C(self):
        #DFS order from C matches theoretical DFS
        visited = self.g.dfs('C')
        self.assertEqual(visited[0], 'C')
        self.assertEqual(set(visited), set(graph.keys()))

    def test_interactive_start_node(self):
        #BFS restarts correctly from chosen node
        visited = self.g.bfs('D')
        self.assertEqual(visited[0], 'D')
        self.assertIn('B', visited)

    def test_bfs_all_nodes_visited(self):
        for start in graph.keys():
            self.assertEqual(set(self.g.bfs(start)), set(graph.keys()))

    def test_dfs_all_nodes_visited(self):
        for start in graph.keys():
            self.assertEqual(set(self.g.dfs(start)), set(graph.keys()))


if __name__ == "__main__":
    unittest.main()
