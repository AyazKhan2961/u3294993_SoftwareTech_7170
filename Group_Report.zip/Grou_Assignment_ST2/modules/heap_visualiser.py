import pygame
import sys
import random
import heapq

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Heap Visualiser")

clock = pygame.time.Clock()

FONT = pygame.font.SysFont(None, 26)
SMALL_FONT = pygame.font.SysFont(None, 20)

WHITE = (240, 240, 240)
BLACK = (0, 0, 0)
BLUE = (100, 180, 255)
RED = (255, 100, 100)



def get_node_position(index):
    if index == 0:
        return 400, 120

    level = 0
    count = index + 1

    while count > 1:
        count //= 2
        level += 1

    level_start = 2 ** level - 1
    position_in_level = index - level_start
    nodes_in_level = 2 ** level

    spacing = WIDTH // (nodes_in_level + 1)
    x = spacing * (position_in_level + 1)
    y = 120 + level * 90

    return x, y


def draw_heap(screen, heap, message="", highlighted_index=None):
    screen.fill(WHITE)

    # title
    title = FONT.render("Heap Visualiser (I=Insert, E=Extract)", True, BLACK)
    screen.blit(title, (200, 30))

    # dynamic message
    msg = FONT.render(message, True, BLACK)
    screen.blit(msg, (80, 530))

    # persistent hint (FIXED: always visible)
    hint = SMALL_FONT.render("I: Insert | E: Extract | ESC: Exit", True, (120, 120, 120))
    screen.blit(hint, (80, 560))

    # draw edges
    for i in range(len(heap)):
        x1, y1 = get_node_position(i)

        left = 2 * i + 1
        right = 2 * i + 2

        if left < len(heap):
            x2, y2 = get_node_position(left)
            pygame.draw.line(screen, BLACK, (x1, y1), (x2, y2), 2)

        if right < len(heap):
            x2, y2 = get_node_position(right)
            pygame.draw.line(screen, BLACK, (x1, y1), (x2, y2), 2)

    # draw nodes
    for i, val in enumerate(heap):
        x, y = get_node_position(i)

        color = BLUE
        if i == highlighted_index:
            color = RED

        pygame.draw.circle(screen, color, (x, y), 25)
        pygame.draw.circle(screen, BLACK, (x, y), 2)

        text = FONT.render(str(val), True, BLACK)
        screen.blit(text, text.get_rect(center=(x, y)))

    # heap array view
    array_text = FONT.render("Heap array: " + str(heap), True, BLACK)
    screen.blit(array_text, (80, 80))

    pygame.display.flip()


#the animation for inserting and extracting   
def animate_insert(screen, heap, value):
    heapq.heappush(heap, value)

    index = len(heap) - 1

    draw_heap(screen, heap, f"Inserted {value}", highlighted_index=index)
    pygame.time.wait(600)

    draw_heap(screen, heap, "Heap property restored")



def animate_extract(screen, heap):
    if not heap:
        draw_heap(screen, heap, "Heap is empty")
        pygame.time.wait(600)
        return None

    removed = heap[0]

    draw_heap(screen, heap, f"Extracting {removed}", highlighted_index=0)
    pygame.time.wait(600)

    heapq.heappop(heap)

    draw_heap(screen, heap, f"Extracted {removed}")
    pygame.time.wait(600)

    return removed


# the main loop
def run(screen):
    heap = []

    message = "Press I to insert random value, E to extract min"

    running = True

    while running:

        draw_heap(screen, heap, message)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    running = False

                elif event.key == pygame.K_i:
                    value = random.randint(1, 100)
                    animate_insert(screen, heap, value)
                    message = f"Inserted {value}"

                elif event.key == pygame.K_e:
                    removed = animate_extract(screen, heap)
                    message = (
                        f"Extracted {removed}"
                        if removed is not None
                        else "Heap is empty"
                    )

        clock.tick(30)



if __name__ == "__main__":
    run(screen)