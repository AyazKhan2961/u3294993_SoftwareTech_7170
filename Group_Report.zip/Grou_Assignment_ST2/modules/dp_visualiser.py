# reference: Week 12 & https://github.com/nas-programmer/path-finding/blob/master/astar.py

import pygame
import sys
import math
import unittest

WIDTH, HEIGHT = 800, 600


ROWS, COLS = 6, 6
CELL_SIZE = 600 // COLS
clock = pygame.time.Clock()




def draw_grid(screen, font, dp, highlight=None, obstacles=None, path=None):
    screen.fill((255, 255, 255))
    if obstacles is None:
        obstacles = set()
    if path is None:
        path = set()

    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c * CELL_SIZE, r * CELL_SIZE,
                               CELL_SIZE, CELL_SIZE)
            if (r, c) in obstacles:
                color = (80, 80, 80)
            elif (r, c) == (0, 0):
                color = (100, 220, 100)
            elif (r, c) == (ROWS - 1, COLS - 1):
                color = (220, 100, 100)
            elif (r, c) in path:
                color = (255, 220, 80)
            elif highlight == (r, c):
                color = (255, 180, 180)
            else:
                color = (200, 200, 200)

            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 1)

            val = dp[r][c]
            if val is not None and (r, c) not in obstacles:
                text = font.render(str(val), True, (0, 0, 0))
                text_rect = text.get_rect(center=rect.center)
                screen.blit(text, text_rect)

    pygame.display.flip()



def count_paths(screen, font, obstacles=None):
    if obstacles is None:
        obstacles = set()
    dp = [[None] * COLS for _ in range(ROWS)]
    for r in range(ROWS):
        for c in range(COLS):
            if (r, c) in obstacles:
                dp[r][c] = 0
            elif r == 0 and c == 0:
                dp[r][c] = 1
            else:
                up = dp[r - 1][c] if r > 0 else 0
                left = dp[r][c - 1] if c > 0 else 0
                if up is None:
                    up = 0
                if left is None:
                    left = 0
                dp[r][c] = up + left

            draw_grid(screen, font, dp, highlight=(r, c),
                      obstacles=obstacles)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            pygame.time.wait(300)

    return dp



def reconstruct_path(dp, obstacles=None):
    if obstacles is None:
        obstacles = set()
    if dp[ROWS - 1][COLS - 1] is None or dp[ROWS - 1][COLS - 1] == 0:
        return set()
    path = set()
    r, c = ROWS - 1, COLS - 1
    path.add((r, c))
    while r > 0 or c > 0:
        up = dp[r - 1][c] if r > 0 and dp[r - 1][c] else 0
        left = dp[r][c - 1] if c > 0 and dp[r][c - 1] else 0
        if up >= left and r > 0:
            r -= 1
        elif c > 0:
            c -= 1
        else:
            break
        path.add((r, c))
    return path


def dp_grid_visualization(screen, font):
    obstacles = set()
    dp = [[None] * COLS for _ in range(ROWS)]
    path = set()
    computed = False
    info_font = pygame.font.SysFont(None, 22)
    running = True
    mouse_held = False

    def draw_state():
        draw_grid(screen, font, dp, obstacles=obstacles, path=path)
        hint = info_font.render(
            "Click: toggle obstacle | SPACE: compute | R: reset | ESC: menu",
            True, (60, 60, 60))
        screen.blit(hint, (10, HEIGHT - 22))
        if computed and dp[ROWS - 1][COLS - 1] is not None:
            total = dp[ROWS - 1][COLS - 1]
            rt = font.render(f"Total paths: {total}", True, (0, 120, 0))
            screen.blit(rt, (10, HEIGHT - 48))
        pygame.display.flip()

    while running:
        draw_state()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    dp = count_paths(screen, font, obstacles)
                    path = reconstruct_path(dp, obstacles)
                    computed = True
                elif event.key == pygame.K_r:
                    obstacles.clear()
                    dp = [[None] * COLS for _ in range(ROWS)]
                    path = set()
                    computed = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_held = True
            elif event.type == pygame.MOUSEBUTTONUP:
                mouse_held = False

        if mouse_held:
            mx, my = pygame.mouse.get_pos()
            c = mx // CELL_SIZE
            r = my // CELL_SIZE
            if 0 <= r < ROWS and 0 <= c < COLS:
                cell = (r, c)
                if cell not in {(0, 0), (ROWS - 1, COLS - 1)}:
                    if cell in obstacles:
                        obstacles.discard(cell)
                    else:
                        obstacles.add(cell)
                    dp = [[None] * COLS for _ in range(ROWS)]
                    path = set()
                    computed = False

        clock.tick(30)



def coin_change_visualization(screen, font):
    coins = [1, 3, 4]
    amount = 10
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    info_font = pygame.font.SysFont(None, 24)
    step_amt = [1]
    running = True

    def draw_coin_change(dp_state, current_amt=None):
        screen.fill((255, 255, 255))
        cell_w = (WIDTH - 40) // (amount + 1)
        cell_h = 80
        title = font.render(
            f"Coin Change: coins={coins}, amount={amount}",
            True, (50, 50, 150))
        screen.blit(title, (10, 10))
        for i in range(amount + 1):
            x = 20 + i * cell_w
            y = 120
            if i == current_amt:
                color = (255, 200, 80)
            elif dp_state[i] == float('inf'):
                color = (200, 180, 180)
            else:
                color = (200, 200, 220)
            pygame.draw.rect(screen, color, (x, y, cell_w - 2, cell_h))
            pygame.draw.rect(screen, (0, 0, 0), (x, y, cell_w - 2, cell_h), 1)
            val_str = "inf" if dp_state[i] == float('inf') else str(dp_state[i])
            vt = info_font.render(val_str, True, (0, 0, 0))
            screen.blit(vt, (x + cell_w // 2 - vt.get_width() // 2,
                              y + cell_h // 2 - vt.get_height() // 2))
            lt = info_font.render(str(i), True, (80, 80, 80))
            screen.blit(lt, (x + cell_w // 2 - lt.get_width() // 2, y + cell_h + 5))

        result_str = (f"Min coins for {amount}: {dp_state[amount]}"
                      if dp_state[amount] != float('inf') else "No solution")
        screen.blit(font.render(result_str, True, (0, 120, 0)), (10, 240))
        hint = info_font.render("SPACE: step | R: reset | ESC: back", True, (120, 120, 120))
        screen.blit(hint, (10, HEIGHT - 28))
        pygame.display.flip()

    draw_coin_change(dp)
    pygame.time.wait(500)

    while running:
        draw_coin_change(dp, step_amt[0] if step_amt[0] <= amount else None)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_r:
                    dp = [float('inf')] * (amount + 1)
                    dp[0] = 0
                    step_amt[0] = 1
                elif event.key == pygame.K_SPACE:
                    if step_amt[0] <= amount:
                        for coin in coins:
                            if coin <= step_amt[0]:
                                if dp[step_amt[0] - coin] + 1 < dp[step_amt[0]]:
                                    dp[step_amt[0]] = dp[step_amt[0] - coin] + 1
                        step_amt[0] += 1
        clock.tick(30)



def astar_pathfinding(screen):
   
    W, H = 600, 600
    cols_a, rows_a = 50, 50
    w = W // cols_a
    h = H // rows_a

    grid_a = []
    openSet = []
    closeSet = []
    path_a = []

    def heuristics(a, b):
        return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2)

    class SpotA:
        def __init__(self, i, j):
            self.x, self.y = i, j
            self.f, self.g, self.h = 0, 0, 0
            self.neighbors = []
            self.prev = None
            self.wall = False

        def show(self, win, col):
            if self.wall:
                col = (0, 0, 0)
            pygame.draw.rect(win, col, (self.x * w, self.y * h, w - 1, h - 1))

        def add_neighbors(self, g):
            if self.x < cols_a - 1:
                self.neighbors.append(g[self.x + 1][self.y])
            if self.x > 0:
                self.neighbors.append(g[self.x - 1][self.y])
            if self.y < rows_a - 1:
                self.neighbors.append(g[self.x][self.y + 1])
            if self.y > 0:
                self.neighbors.append(g[self.x][self.y - 1])
            # Diagonals as in original
            if self.x < cols_a - 1 and self.y < rows_a - 1:
                self.neighbors.append(g[self.x + 1][self.y + 1])
            if self.x < cols_a - 1 and self.y > 0:
                self.neighbors.append(g[self.x + 1][self.y - 1])
            if self.x > 0 and self.y < rows_a - 1:
                self.neighbors.append(g[self.x - 1][self.y + 1])
            if self.x > 0 and self.y > 0:
                self.neighbors.append(g[self.x - 1][self.y - 1])

    for i in range(cols_a):
        arr = []
        for j in range(rows_a):
            arr.append(SpotA(i, j))
        grid_a.append(arr)

    for i in range(cols_a):
        for j in range(rows_a):
            grid_a[i][j].add_neighbors(grid_a)

    start_a = grid_a[0][0]
    end_a = grid_a[cols_a - cols_a // 2][rows_a - cols_a // 4]
    openSet.append(start_a)

    flag = False
    noflag = True
    startflag = False

    def clickWall(pos, state):
        i = pos[0] // w
        j = pos[1] // h
        if 0 <= i < cols_a and 0 <= j < rows_a:
            grid_a[i][j].wall = state

    running = True
    info_font = pygame.font.SysFont(None, 22)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if pygame.mouse.get_pressed(3)[0]:
                    clickWall(pygame.mouse.get_pos(), True)
                if pygame.mouse.get_pressed(3)[2]:
                    clickWall(pygame.mouse.get_pos(), False)
            if event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_pressed()[0]:
                    clickWall(pygame.mouse.get_pos(), True)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    startflag = True
                if event.key == pygame.K_ESCAPE:
                    running = False

        if startflag:
            if len(openSet) > 0:
                winner = 0
                for i in range(len(openSet)):
                    if openSet[i].f < openSet[winner].f:
                        winner = i
                current_a = openSet[winner]
                if current_a == end_a:
                    temp = current_a
                    while temp.prev:
                        path_a.append(temp.prev)
                        temp = temp.prev
                    if not flag:
                        flag = True
                    elif flag:
                        pass
                if not flag:
                    openSet.remove(current_a)
                    closeSet.append(current_a)
                    for neighbor in current_a.neighbors:
                        if neighbor in closeSet or neighbor.wall:
                            continue
                        tempG = current_a.g + 1
                        newPath = False
                        if neighbor in openSet:
                            if tempG < neighbor.g:
                                neighbor.g = tempG
                                newPath = True
                        else:
                            neighbor.g = tempG
                            newPath = True
                            openSet.append(neighbor)
                        if newPath:
                            neighbor.h = heuristics(neighbor, end_a)
                            neighbor.f = neighbor.g + neighbor.h
                            neighbor.prev = current_a
            else:
                if noflag:
                    noflag = False

        screen.fill((0, 20, 20))
        for i in range(cols_a):
            for j in range(rows_a):
                spot = grid_a[j][i]
                spot.show(screen, (255, 255, 255))
                if flag and spot in path_a:
                    spot.show(screen, (25, 120, 250))
                elif spot in closeSet:
                    spot.show(screen, (255, 0, 0))
                elif spot in openSet:
                    spot.show(screen, (0, 255, 0))
                try:
                    if spot == end_a:
                        spot.show(screen, (0, 120, 255))
                except Exception:
                    pass

        hint = info_font.render(
            "Click:wall  ENTER:start  ESC:back", True, (200, 200, 200))
        screen.blit(hint, (10, 10))
        pygame.display.flip()
        clock.tick(30)



def run(screen):
    font = pygame.font.SysFont(None, 30)
    menu_items = [
        "Grid Path DP (SPACE: compute, click: obstacle)",
        "Coin Change DP (SPACE: step, R: reset)",
        "A* Pathfinding (ENTER: start, click: wall)",
        "Back"
    ]
    selected = 0
    running = True

    while running:
        screen.fill((220, 220, 220))
        title_font = pygame.font.SysFont(None, 36)
        title = title_font.render("Phase 3: DP Puzzles & Pathfinding",
                                  True, (50, 50, 150))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))
        for i, item in enumerate(menu_items):
            color = (255, 0, 0) if i == selected else (0, 0, 0)
            text = font.render(item, True, color)
            screen.blit(text, (40, 130 + i * 80))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    if "Grid" in menu_items[selected]:
                        dp_grid_visualization(screen, font)
                    elif "Coin" in menu_items[selected]:
                        coin_change_visualization(screen, font)
                    elif "A*" in menu_items[selected]:
                        astar_pathfinding(screen)
                    elif menu_items[selected] == "Back":
                        running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for i, item in enumerate(menu_items):
                    rect = pygame.Rect(40, 130 + i * 80, 700, 55)
                    if rect.collidepoint(pos):
                        if "Grid" in item:
                            dp_grid_visualization(screen, font)
                        elif "Coin" in item:
                            coin_change_visualization(screen, font)
                        elif "A*" in item:
                            astar_pathfinding(screen)
                        elif item == "Back":
                            running = False
        clock.tick(30)



def _count_paths_logic(rows, cols, obstacles=None):
    if obstacles is None:
        obstacles = set()
    dp = [[0] * cols for _ in range(rows)]
    for r in range(rows):
        for c in range(cols):
            if (r, c) in obstacles:
                dp[r][c] = 0
            elif r == 0 and c == 0:
                dp[r][c] = 1
            else:
                up = dp[r - 1][c] if r > 0 else 0
                left = dp[r][c - 1] if c > 0 else 0
                dp[r][c] = up + left
    return dp


def _coin_change_logic(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for i in range(1, amount + 1):
        for coin in coins:
            if coin <= i and dp[i - coin] + 1 < dp[i]:
                dp[i] = dp[i - coin] + 1
    return dp[amount] if dp[amount] != float('inf') else -1


class TestDP(unittest.TestCase):

    def test_grid_path_no_obstacles(self):
        #6x6 grid with no obstacles — 252 unique paths from top-left to bottom-right
        dp = _count_paths_logic(6, 6)
        self.assertEqual(dp[5][5], 252)

    def test_grid_path_with_obstacle(self):
        dp_no = _count_paths_logic(6, 6)
        dp_ob = _count_paths_logic(6, 6, obstacles={(2, 2)})
        self.assertLess(dp_ob[5][5], dp_no[5][5])

    def test_grid_path_blocked(self):
        dp = _count_paths_logic(2, 2, obstacles={(0, 1), (1, 0)})
        self.assertEqual(dp[1][1], 0)

    def test_coin_change_basic(self):
        
        self.assertEqual(_coin_change_logic([1, 3, 4], 6), 2)

    def test_coin_change_amount_zero(self):
        self.assertEqual(_coin_change_logic([1, 3, 4], 0), 0)

    def test_coin_change_no_solution(self):
        self.assertEqual(_coin_change_logic([3, 5], 1), -1)

    def test_reconstruct_path_exists(self):
        dp = _count_paths_logic(6, 6)
        path = reconstruct_path(dp)
        self.assertIn((0, 0), path)
        self.assertIn((5, 5), path)

    def test_path_length(self):
        
        dp = _count_paths_logic(ROWS, COLS)
        path = reconstruct_path(dp)
        self.assertEqual(len(path), ROWS + COLS - 1)


if __name__ == "__main__":
    unittest.main()
