import pygame
import sys
import random
import heapq
import math
from collections import deque

WIDTH, HEIGHT = 900, 620
clock = pygame.time.Clock()


# ============================================================
# SORTING VISUALISER
# ============================================================
def _draw_array(screen, font, array, color_positions=None, title=""):
    screen.fill((30, 30, 30))
    bar_width = (WIDTH - 40) // len(array)
    max_val = max(array) if array else 1
    for i, val in enumerate(array):
        color = (100, 200, 250)
        if color_positions:
            if i in color_positions.get('compare', []):
                color = (255, 100, 100)
            if i in color_positions.get('swap', []):
                color = (100, 255, 100)
            if i in color_positions.get('sorted', []):
                color = (150, 150, 150)
        bar_h = int((val / max_val) * (HEIGHT - 120))
        pygame.draw.rect(screen, color,
                         (20 + i * bar_width, HEIGHT - 80 - bar_h, bar_width - 2, bar_h))
    if title:
        t = font.render(title, True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))
    hint = pygame.font.SysFont(None, 22).render("ESC: back | R: reset", True, (140, 140, 140))
    screen.blit(hint, (10, HEIGHT - 25))
    pygame.display.flip()


def bubble_sort_visualization(screen, font, small_font):
    array = [random.randint(20, 350) for _ in range(30)]
    n = len(array)
    running = True

    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            _draw_array(screen, font, array,
                        {'compare': [j, j + 1], 'swap': [], 'sorted': list(range(n - i, n))},
                        "Bubble Sort")
            pygame.time.wait(40)
            if array[j] > array[j + 1]:
                array[j], array[j + 1] = array[j + 1], array[j]
                swapped = True
                _draw_array(screen, font, array,
                            {'compare': [], 'swap': [j, j + 1], 'sorted': list(range(n - i, n))},
                            "Bubble Sort")
                pygame.time.wait(40)
        if not swapped:
            break

    _draw_array(screen, font, array, {'sorted': list(range(n))}, "Bubble Sort - Done!")
    pygame.time.wait(1500)


def selection_sort_visualization(screen, font, small_font):
    array = [random.randint(20, 350) for _ in range(30)]
    n = len(array)
    sorted_indices = []

    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            _draw_array(screen, font, array,
                        {'compare': [j, min_idx], 'swap': [], 'sorted': sorted_indices},
                        "Selection Sort")
            pygame.time.wait(30)
            if array[j] < array[min_idx]:
                min_idx = j
        if min_idx != i:
            array[i], array[min_idx] = array[min_idx], array[i]
            _draw_array(screen, font, array,
                        {'compare': [], 'swap': [i, min_idx], 'sorted': sorted_indices},
                        "Selection Sort")
            pygame.time.wait(40)
        sorted_indices.append(i)

    _draw_array(screen, font, array, {'sorted': list(range(n))}, "Selection Sort - Done!")
    pygame.time.wait(1500)


def merge_sort_visualization(screen, font, small_font):
    array = [random.randint(20, 350) for _ in range(30)]
    highlight = [False] * len(array)

    def merge(arr, l, m, r):
        left = arr[l:m + 1]
        right = arr[m + 1:r + 1]
        i = j = 0
        k = l
        while i < len(left) and j < len(right):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
            cp = {'compare': [k], 'swap': [], 'sorted': []}
            _draw_array(screen, font, arr, cp, "Merge Sort")
            pygame.time.wait(30)
            if left[i] <= right[j]:
                arr[k] = left[i]; i += 1
            else:
                arr[k] = right[j]; j += 1
            k += 1
        while i < len(left):
            arr[k] = left[i]; i += 1; k += 1
        while j < len(right):
            arr[k] = right[j]; j += 1; k += 1

    def merge_sort(arr, l, r):
        if l < r:
            m = (l + r) // 2
            merge_sort(arr, l, m)
            merge_sort(arr, m + 1, r)
            merge(arr, l, m, r)

    merge_sort(array, 0, len(array) - 1)
    _draw_array(screen, font, array, {'sorted': list(range(len(array)))}, "Merge Sort - Done!")
    pygame.time.wait(1500)


def sorting_module(screen, font, small_font):
    options = [
        ("Bubble Sort", bubble_sort_visualization),
        ("Selection Sort", selection_sort_visualization),
        ("Merge Sort", merge_sort_visualization),
        ("Back", None),
    ]
    selected = 0

    while True:
        screen.fill((40, 40, 60))
        title = font.render("Phase 2: Sorting Algorithms", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))

        for i, (label, _) in enumerate(options):
            color = (255, 200, 50) if i == selected else (200, 200, 200)
            rect = pygame.Rect(WIDTH // 2 - 180, 140 + i * 80, 360, 55)
            pygame.draw.rect(screen, (70, 70, 100) if i != selected else (90, 90, 140), rect, border_radius=8)
            pygame.draw.rect(screen, color, rect, 2, border_radius=8)
            txt = font.render(label, True, color)
            screen.blit(txt, (rect.x + rect.width // 2 - txt.get_width() // 2,
                               rect.y + rect.height // 2 - txt.get_height() // 2))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(options)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(options)
                elif event.key == pygame.K_RETURN:
                    label, func = options[selected]
                    if func is None:
                        return
                    func(screen, font, small_font)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for i, (label, func) in enumerate(options):
                    rect = pygame.Rect(WIDTH // 2 - 180, 140 + i * 80, 360, 55)
                    if rect.collidepoint(pos):
                        if func is None:
                            return
                        func(screen, font, small_font)
        clock.tick(30)


# ============================================================
# GRAPH TRAVERSAL VISUALISER
# ============================================================
nodes_pos = {
    'A': (150, 150),
    'B': (350, 80),
    'C': (350, 250),
    'D': (550, 100),
    'E': (700, 180),
    'F': (550, 320),
}
graph_adj = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E'],
}

NODE_R = 28


def _draw_graph(screen, font, small_font, visited=None, frontier=None, current=None,
                traversal_order=None, title=""):
    screen.fill((30, 30, 30))
    if title:
        t = font.render(title, True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))

    # Edges
    for node, neighbors in graph_adj.items():
        x1, y1 = nodes_pos[node]
        for nbr in neighbors:
            x2, y2 = nodes_pos[nbr]
            pygame.draw.line(screen, (120, 120, 120), (x1, y1), (x2, y2), 2)

    # Nodes
    for node, (x, y) in nodes_pos.items():
        color = (80, 80, 80)
        if visited and node in visited:
            color = (80, 200, 80)
        if frontier and node in frontier:
            color = (255, 200, 80)
        if current and node == current:
            color = (255, 80, 80)
        pygame.draw.circle(screen, color, (x, y), NODE_R)
        pygame.draw.circle(screen, (255, 255, 255), (x, y), NODE_R, 2)
        txt = font.render(node, True, (255, 255, 255))
        screen.blit(txt, (x - txt.get_width() // 2, y - txt.get_height() // 2))

    if traversal_order:
        order_str = " -> ".join(traversal_order)
        o = small_font.render(f"Order: {order_str}", True, (220, 220, 100))
        screen.blit(o, (10, HEIGHT - 55))

    hint = small_font.render("B: BFS | D: DFS | Click node = start | ESC: back", True, (140, 140, 140))
    screen.blit(hint, (10, HEIGHT - 28))
    pygame.display.flip()


def graph_module(screen, font, small_font):
    running = True
    visited = set()
    frontier = set()
    current_node = None
    traversal_order = []
    start_vertex = 'A'
    mode = None

    def run_bfs(start):
        nonlocal visited, frontier, traversal_order, current_node
        visited = set()
        traversal_order = []
        q = deque([start])
        seen = {start}
        while q:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            v = q.popleft()
            visited.add(v)
            current_node = v
            traversal_order.append(v)
            frontier = set(q)
            _draw_graph(screen, font, small_font, visited, frontier, current_node,
                        traversal_order, "Graph BFS Traversal")
            pygame.time.wait(700)
            for nbr in graph_adj[v]:
                if nbr not in seen:
                    seen.add(nbr)
                    q.append(nbr)
        current_node = None
        _draw_graph(screen, font, small_font, visited, set(), current_node, traversal_order,
                    "Graph BFS - Complete")
        pygame.time.wait(1000)

    def run_dfs(start):
        nonlocal visited, frontier, traversal_order, current_node
        visited = set()
        traversal_order = []
        stack = [start]
        seen = set()
        while stack:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return
            v = stack.pop()
            if v not in seen:
                seen.add(v)
                visited.add(v)
                current_node = v
                traversal_order.append(v)
                frontier = set(stack)
                _draw_graph(screen, font, small_font, visited, frontier, current_node,
                            traversal_order, "Graph DFS Traversal")
                pygame.time.wait(700)
                for nbr in reversed(graph_adj[v]):
                    if nbr not in seen:
                        stack.append(nbr)
        current_node = None
        _draw_graph(screen, font, small_font, visited, set(), current_node, traversal_order,
                    "Graph DFS - Complete")
        pygame.time.wait(1000)

    while running:
        _draw_graph(screen, font, small_font, visited, frontier, current_node,
                    traversal_order, f"Graph Traversal | Start: {start_vertex}")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_b:
                    run_bfs(start_vertex)
                elif event.key == pygame.K_d:
                    run_dfs(start_vertex)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Allow clicking a node to set start vertex
                pos = event.pos
                for node, (nx, ny) in nodes_pos.items():
                    dx, dy = pos[0] - nx, pos[1] - ny
                    if math.sqrt(dx * dx + dy * dy) <= NODE_R:
                        start_vertex = node
                        visited = set()
                        traversal_order = []
                        current_node = None

        clock.tick(30)


# ============================================================
# HEAP VISUALISER
# ============================================================
def _draw_heap_tree(screen, font, small_font, heap, highlight_indices=None, title=""):
    screen.fill((30, 30, 30))
    if title:
        t = font.render(title, True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))

    if not heap:
        msg = font.render("Heap is empty", True, (180, 180, 180))
        screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, HEIGHT // 2))
        pygame.display.flip()
        return

    node_positions = []
    for i in range(len(heap)):
        level = int(math.floor(math.log2(i + 1)))
        index_in_level = i - (2 ** level - 1)
        gap = WIDTH // (2 ** level + 1)
        x = gap * (index_in_level + 1)
        y = 60 + level * 90
        node_positions.append((x, y))

    for i in range(len(heap)):
        left = 2 * i + 1
        right = 2 * i + 2
        if left < len(heap):
            pygame.draw.line(screen, (120, 120, 120), node_positions[i], node_positions[left], 2)
        if right < len(heap):
            pygame.draw.line(screen, (120, 120, 120), node_positions[i], node_positions[right], 2)

    for i, val in enumerate(heap):
        x, y = node_positions[i]
        color = (255, 100, 100) if highlight_indices and i in highlight_indices else (255, 165, 0)
        pygame.draw.circle(screen, color, (x, y), 22)
        pygame.draw.circle(screen, (255, 255, 255), (x, y), 22, 2)
        txt = font.render(str(val), True, (0, 0, 0))
        screen.blit(txt, (x - txt.get_width() // 2, y - txt.get_height() // 2))

    # Array representation at bottom
    arr_txt = small_font.render("Array: " + str(heap), True, (200, 200, 200))
    screen.blit(arr_txt, (10, HEIGHT - 55))

    hint = small_font.render("I: Insert random | E: Extract-min | ESC: back", True, (140, 140, 140))
    screen.blit(hint, (10, HEIGHT - 28))

    pygame.display.flip()


def heap_module(screen, font, small_font):
    heap = []
    running = True

    def heapify_up(h, index):
        while index > 0:
            parent = (index - 1) // 2
            if h[parent] > h[index]:
                h[parent], h[index] = h[index], h[parent]
                _draw_heap_tree(screen, font, small_font, h, [parent, index], "Heap - Heapify Up")
                pygame.time.wait(400)
                index = parent
            else:
                break

    def heapify_down(h, index):
        n = len(h)
        while True:
            left = 2 * index + 1
            right = 2 * index + 2
            smallest = index
            if left < n and h[left] < h[smallest]:
                smallest = left
            if right < n and h[right] < h[smallest]:
                smallest = right
            if smallest != index:
                h[index], h[smallest] = h[smallest], h[index]
                _draw_heap_tree(screen, font, small_font, h, [index, smallest], "Heap - Heapify Down")
                pygame.time.wait(400)
                index = smallest
            else:
                break

    while running:
        _draw_heap_tree(screen, font, small_font, heap, title="Min-Heap Visualiser")

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_i:
                    val = random.randint(1, 99)
                    heap.append(val)
                    _draw_heap_tree(screen, font, small_font, heap, [len(heap) - 1], f"Inserted {val}")
                    pygame.time.wait(300)
                    heapify_up(heap, len(heap) - 1)
                elif event.key == pygame.K_e:
                    if heap:
                        root = heap[0]
                        heap[0] = heap[-1]
                        heap.pop()
                        _draw_heap_tree(screen, font, small_font, heap, [0], f"Extracted {root}")
                        pygame.time.wait(300)
                        if heap:
                            heapify_down(heap, 0)
        clock.tick(30)


# ============================================================
# PHASE 2 MENU
# ============================================================
def run(screen):
    font = pygame.font.SysFont(None, 32)
    small_font = pygame.font.SysFont(None, 22)

    menu_items = [
        ("Sorting Algorithms", lambda s, f, sf: sorting_module(s, f, sf)),
        ("Graph BFS / DFS", graph_module),
        ("Heap Visualiser", heap_module),
        ("Back to Main Menu", None),
    ]
    selected = 0

    while True:
        screen.fill((40, 40, 60))
        title = font.render("Phase 2: Algorithm Visualiser", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))

        for i, (label, _) in enumerate(menu_items):
            color = (255, 200, 50) if i == selected else (200, 200, 200)
            rect = pygame.Rect(WIDTH // 2 - 180, 130 + i * 90, 360, 60)
            pygame.draw.rect(screen, (70, 70, 100) if i != selected else (90, 90, 140), rect, border_radius=8)
            pygame.draw.rect(screen, color, rect, 2, border_radius=8)
            txt = font.render(label, True, color)
            screen.blit(txt, (rect.x + rect.width // 2 - txt.get_width() // 2,
                               rect.y + rect.height // 2 - txt.get_height() // 2))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    label, func = menu_items[selected]
                    if func is None:
                        return
                    func(screen, font, small_font)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for i, (label, func) in enumerate(menu_items):
                    rect = pygame.Rect(WIDTH // 2 - 180, 130 + i * 90, 360, 60)
                    if rect.collidepoint(pos):
                        if func is None:
                            return
                        func(screen, font, small_font)

        clock.tick(30)
