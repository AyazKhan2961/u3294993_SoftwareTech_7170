import pygame
import sys
from modules.stack import Stack
from modules.queue_ds import Queue
from modules.linked_list import SinglyLinkedList
from modules.bst import BST


# ---- Layout constants ----
WIDTH, HEIGHT = 900, 620
BLOCK_WIDTH, BLOCK_HEIGHT = 160, 40
VERTICAL_GAP = 8
NODE_RADIUS = 24

clock = pygame.time.Clock()


# ============================================================
# STACK VISUALISER
# ============================================================
def stack_visualization(screen, font, small_font):
    stack = Stack()
    counter = 1
    running = True
    input_str = ""
    message = "SPACE: Push | BACKSPACE: Pop | ESC: Menu"

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    stack.push(counter)
                    message = f"Pushed {counter}"
                    counter += 1
                elif event.key == pygame.K_BACKSPACE:
                    if not stack.is_empty():
                        val = stack.pop()
                        message = f"Popped {val}"
                    else:
                        message = "Stack is empty!"

        screen.fill((30, 30, 30))

        # Title
        title = font.render("Stack Visualiser", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 12))

        # Instructions
        inst = small_font.render(message, True, (180, 180, 180))
        screen.blit(inst, (10, HEIGHT - 30))

        # Draw stack blocks from bottom
        base_x = (WIDTH - BLOCK_WIDTH) // 2
        base_y = HEIGHT - 80

        for i, val in enumerate(stack._data):
            y = base_y - i * (BLOCK_HEIGHT + VERTICAL_GAP)
            color = (100, 150, 250) if i < stack.size() - 1 else (100, 220, 120)
            pygame.draw.rect(screen, color, (base_x, y, BLOCK_WIDTH, BLOCK_HEIGHT), border_radius=6)
            pygame.draw.rect(screen, (255, 255, 255), (base_x, y, BLOCK_WIDTH, BLOCK_HEIGHT), 2, border_radius=6)
            txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(txt, (base_x + BLOCK_WIDTH // 2 - txt.get_width() // 2,
                               y + BLOCK_HEIGHT // 2 - txt.get_height() // 2))

        # TOP label
        if not stack.is_empty():
            top_y = base_y - (stack.size() - 1) * (BLOCK_HEIGHT + VERTICAL_GAP)
            lbl = small_font.render("<-- TOP", True, (255, 100, 100))
            screen.blit(lbl, (base_x + BLOCK_WIDTH + 10, top_y + 8))

        # Size info
        size_txt = small_font.render(f"Size: {stack.size()}", True, (220, 220, 220))
        screen.blit(size_txt, (10, 50))

        pygame.display.flip()
        clock.tick(30)


# ============================================================
# QUEUE VISUALISER
# ============================================================
def queue_visualization(screen, font, small_font):
    queue = Queue()
    counter = 1
    running = True
    message = "E: Enqueue | D: Dequeue | ESC: Menu"

    QBLOCK_W = 80
    QBLOCK_H = 50

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_e:
                    queue.enqueue(counter)
                    message = f"Enqueued {counter}"
                    counter += 1
                elif event.key == pygame.K_d:
                    if not queue.is_empty():
                        val = queue.dequeue()
                        message = f"Dequeued {val}"
                    else:
                        message = "Queue is empty!"

        screen.fill((30, 30, 30))

        title = font.render("Queue Visualiser", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 12))

        inst = small_font.render(message, True, (180, 180, 180))
        screen.blit(inst, (10, HEIGHT - 30))

        # Draw queue items left to right
        items = list(queue._data)
        start_x = 40
        y = HEIGHT // 2 - QBLOCK_H // 2

        for i, val in enumerate(items):
            x = start_x + i * (QBLOCK_W + 10)
            color = (250, 150, 80) if i == 0 else (100, 150, 250)
            pygame.draw.rect(screen, color, (x, y, QBLOCK_W, QBLOCK_H), border_radius=6)
            pygame.draw.rect(screen, (255, 255, 255), (x, y, QBLOCK_W, QBLOCK_H), 2, border_radius=6)
            txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(txt, (x + QBLOCK_W // 2 - txt.get_width() // 2,
                               y + QBLOCK_H // 2 - txt.get_height() // 2))
            # Arrow between blocks
            if i < len(items) - 1:
                ax = x + QBLOCK_W + 2
                ay = y + QBLOCK_H // 2
                pygame.draw.line(screen, (200, 200, 200), (ax, ay), (ax + 8, ay), 2)
                pygame.draw.polygon(screen, (200, 200, 200),
                                    [(ax + 8, ay - 4), (ax + 8, ay + 4), (ax + 14, ay)])

        # FRONT / REAR labels
        if items:
            front_lbl = small_font.render("FRONT", True, (255, 100, 100))
            screen.blit(front_lbl, (start_x, y - 24))
            rear_x = start_x + (len(items) - 1) * (QBLOCK_W + 10)
            rear_lbl = small_font.render("REAR", True, (100, 255, 100))
            screen.blit(rear_lbl, (rear_x, y - 24))

        size_txt = small_font.render(f"Size: {queue.size()}", True, (220, 220, 220))
        screen.blit(size_txt, (10, 50))

        pygame.display.flip()
        clock.tick(30)


# ============================================================
# LINKED LIST VISUALISER
# ============================================================
def linked_list_visualization(screen, font, small_font):
    ll = SinglyLinkedList()
    running = True
    message = "A: Append | R: Reverse | D: Delete last | ESC: Menu"
    counter = 1

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_a:
                    ll.insert_at_end(counter)
                    message = f"Appended {counter}"
                    counter += 1
                elif event.key == pygame.K_r:
                    ll.reverse()
                    message = "List Reversed"
                elif event.key == pygame.K_d:
                    nodes = ll.to_list()
                    if nodes:
                        ll.delete_value(nodes[-1])
                        message = f"Deleted {nodes[-1]}"
                    else:
                        message = "List is empty!"

        screen.fill((30, 30, 30))

        title = font.render("Linked List Visualiser", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 12))

        inst = small_font.render(message, True, (180, 180, 180))
        screen.blit(inst, (10, HEIGHT - 30))

        nodes = ll.to_list()
        NODE_W = 70
        NODE_H = 40
        ARROW_W = 30
        start_x = 40
        y = HEIGHT // 2 - NODE_H // 2

        for i, val in enumerate(nodes):
            x = start_x + i * (NODE_W + ARROW_W)
            pygame.draw.rect(screen, (100, 200, 250), (x, y, NODE_W, NODE_H), border_radius=6)
            pygame.draw.rect(screen, (255, 255, 255), (x, y, NODE_W, NODE_H), 2, border_radius=6)
            txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(txt, (x + NODE_W // 2 - txt.get_width() // 2,
                               y + NODE_H // 2 - txt.get_height() // 2))
            # Arrow
            if i < len(nodes) - 1:
                ax = x + NODE_W + 2
                ay = y + NODE_H // 2
                pygame.draw.line(screen, (200, 200, 200), (ax, ay), (ax + ARROW_W - 4, ay), 2)
                pygame.draw.polygon(screen, (200, 200, 200),
                                    [(ax + ARROW_W - 4, ay - 4),
                                     (ax + ARROW_W - 4, ay + 4),
                                     (ax + ARROW_W + 2, ay)])
            elif i == len(nodes) - 1:
                # NULL pointer
                nx = x + NODE_W + 4
                null_txt = small_font.render("NULL", True, (180, 80, 80))
                screen.blit(null_txt, (nx, y + NODE_H // 2 - 8))

        size_txt = small_font.render(f"Nodes: {len(nodes)}", True, (220, 220, 220))
        screen.blit(size_txt, (10, 50))

        pygame.display.flip()
        clock.tick(30)


# ============================================================
# BST VISUALISER
# ============================================================
def _store_bst_positions(node, x, y, x_offset, positions):
    if node:
        positions[node] = (x, y)
        _store_bst_positions(node.left, x - x_offset, y + 80, max(x_offset // 2, 30), positions)
        _store_bst_positions(node.right, x + x_offset, y + 80, max(x_offset // 2, 30), positions)


def _draw_bst(screen, font, small_font, bst, highlight_nodes=None):
    positions = {}
    _store_bst_positions(bst.root, WIDTH // 2, 80, 200, positions)

    # Draw edges
    for node, (x, y) in positions.items():
        if node.left and node.left in positions:
            lx, ly = positions[node.left]
            pygame.draw.line(screen, (180, 180, 180), (x, y), (lx, ly), 2)
        if node.right and node.right in positions:
            rx, ry = positions[node.right]
            pygame.draw.line(screen, (180, 180, 180), (x, y), (rx, ry), 2)

    # Draw nodes
    for node, (x, y) in positions.items():
        if highlight_nodes and node in highlight_nodes:
            color = (255, 150, 50)
        else:
            color = (100, 200, 250)
        pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
        pygame.draw.circle(screen, (255, 255, 255), (x, y), NODE_RADIUS, 2)
        txt = font.render(str(node.value), True, (0, 0, 0))
        screen.blit(txt, (x - txt.get_width() // 2, y - txt.get_height() // 2))


def bst_visualization(screen, font, small_font):
    bst = BST()
    running = True
    message = "Type number + ENTER to insert | T: traverse | ESC: Menu"
    input_str = ""
    traversal_nodes = []
    traversal_idx = 0
    traversal_timer = 0
    traversal_mode = None

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_RETURN:
                    if input_str.isdigit() or (input_str.startswith('-') and input_str[1:].isdigit()):
                        val = int(input_str)
                        bst.insert(val)
                        message = f"Inserted {val}"
                        input_str = ""
                        traversal_nodes = []
                elif event.key == pygame.K_BACKSPACE:
                    input_str = input_str[:-1]
                elif event.key == pygame.K_i:
                    traversal_nodes = bst.inorder()
                    traversal_idx = 0
                    traversal_timer = 0
                    traversal_mode = "Inorder"
                    message = "Inorder traversal"
                elif event.key == pygame.K_p:
                    traversal_nodes = bst.preorder()
                    traversal_idx = 0
                    traversal_timer = 0
                    traversal_mode = "Preorder"
                    message = "Preorder traversal"
                elif event.key == pygame.K_o:
                    traversal_nodes = bst.postorder()
                    traversal_idx = 0
                    traversal_timer = 0
                    traversal_mode = "Postorder"
                    message = "Postorder traversal"
                elif event.key in (pygame.K_0, pygame.K_1, pygame.K_2, pygame.K_3,
                                   pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7,
                                   pygame.K_8, pygame.K_9):
                    input_str += event.unicode
                elif event.key == pygame.K_MINUS and not input_str:
                    input_str = "-"

        # Advance traversal
        traversal_timer += 1
        if traversal_nodes and traversal_timer >= 40:
            traversal_timer = 0
            traversal_idx += 1
            if traversal_idx >= len(traversal_nodes):
                traversal_idx = len(traversal_nodes)

        screen.fill((30, 30, 30))

        title = font.render("BST Visualiser", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 12))

        inst = small_font.render(message, True, (180, 180, 180))
        screen.blit(inst, (10, HEIGHT - 30))

        hint = small_font.render("Number+ENTER: insert | I: inorder | P: preorder | O: postorder", True, (140, 140, 140))
        screen.blit(hint, (10, HEIGHT - 55))

        # Input box
        inp_txt = font.render(f"Input: {input_str}", True, (200, 220, 255))
        screen.blit(inp_txt, (10, 50))

        if bst.root:
            highlight = set(traversal_nodes[:traversal_idx]) if traversal_nodes else None
            _draw_bst(screen, font, small_font, bst, highlight)

        # Traversal order display
        if traversal_nodes:
            order_str = " -> ".join(str(n.value) for n in traversal_nodes[:traversal_idx])
            order_txt = small_font.render(f"{traversal_mode}: {order_str}", True, (255, 200, 100))
            screen.blit(order_txt, (10, 80))

        pygame.display.flip()
        clock.tick(30)


# ============================================================
# PHASE 1 MENU
# ============================================================
def run(screen):
    font = pygame.font.SysFont(None, 32)
    small_font = pygame.font.SysFont(None, 22)

    menu_items = [
        ("Stack Visualiser", stack_visualization),
        ("Queue Visualiser", queue_visualization),
        ("Linked List Visualiser", linked_list_visualization),
        ("BST Visualiser", bst_visualization),
        ("Back to Main Menu", None),
    ]
    selected = 0

    while True:
        screen.fill((40, 40, 60))

        title = font.render("Phase 1: Data Structures", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))

        for i, (label, _) in enumerate(menu_items):
            color = (255, 200, 50) if i == selected else (200, 200, 200)
            rect = pygame.Rect(WIDTH // 2 - 180, 130 + i * 70, 360, 50)
            pygame.draw.rect(screen, (70, 70, 100) if i != selected else (90, 90, 140), rect, border_radius=8)
            pygame.draw.rect(screen, color, rect, 2, border_radius=8)
            txt = font.render(label, True, color)
            screen.blit(txt, (rect.x + rect.width // 2 - txt.get_width() // 2,
                               rect.y + rect.height // 2 - txt.get_height() // 2))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    label, func = menu_items[selected]
                    if func is None:
                        return
                    func(screen, font, small_font)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for i, (label, func) in enumerate(menu_items):
                    rect = pygame.Rect(WIDTH // 2 - 180, 130 + i * 70, 360, 50)
                    if rect.collidepoint(pos):
                        if func is None:
                            return
                        func(screen, font, small_font)

        clock.tick(30)
