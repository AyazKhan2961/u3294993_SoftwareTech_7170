# modules/stack.py
# Week 10 - Task 1_3

class Stack:
    def __init__(self):
        self._data = []

    def push(self, val):
        self._data.append(val)

    def pop(self):
        if not self.is_empty():
            return self._data.pop()
        raise IndexError("pop from empty stack")

    def peek(self):
        if not self.is_empty():
            return self._data[-1]
        raise IndexError("peek from empty stack")

    def is_empty(self):
        return len(self._data) == 0

    def size(self):
        return len(self._data)

    def __repr__(self):
        return f"Stack({self._data})"


# ============================================================
# Week 10 - Task 1_4
# ============================================================
import unittest
import time


class TestStack(unittest.TestCase):

    def test_push_pop(self):
        s = Stack()
        for i in range(1000):
            s.push(i)
        self.assertEqual(s.size(), 1000)
        for i in reversed(range(1000)):
            v = s.pop()
            self.assertEqual(v, i)
        self.assertTrue(s.is_empty())

    def test_peek_and_exceptions(self):
        s = Stack()
        with self.assertRaises(IndexError):
            s.pop()
        with self.assertRaises(IndexError):
            s.peek()
        s.push(42)
        self.assertEqual(s.peek(), 42)
        self.assertEqual(s.size(), 1)

    def test_benchmark(self):
        s = Stack()
        start = time.time()
        n = 10**6
        for i in range(n):
            s.push(i)
        for i in range(n):
            s.pop()
        end = time.time()
        elapsed = end - start
        print(f"Benchmark push/pop {n} items: {elapsed:.4f} seconds")


if __name__ == "__main__":
    unittest.main()
