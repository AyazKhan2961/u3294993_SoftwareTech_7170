import pygame
import sys
import heapq

clock = pygame.time.Clock()

WIDTH, HEIGHT = 800, 600
FONT = None

WHITE = (240, 240, 240)
BLACK = (0, 0, 0)
BLUE = (100, 180, 255)
GREEN = (100, 230, 120)
RED = (255, 100, 100)
YELLOW = (255, 230, 100)


def draw_button(screen, text, rect):
    pygame.draw.rect(screen, (170, 170, 220), rect)
    pygame.draw.rect(screen, BLACK, rect, 2)

    label = FONT.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)


def get_node_position(index):
    if index == 0:
        return 400, 120

    level = 0
    count = index + 1

    while count > 1:
        count //= 2
        level += 1

    level_start = 2 ** level - 1
    position_in_level = index - level_start
    nodes_in_level = 2 ** level

    spacing = WIDTH // (nodes_in_level + 1)
    x = spacing * (position_in_level + 1)
    y = 120 + level * 90

    return x, y


def draw_heap(screen, heap, message="", highlighted_index=None):
    screen.fill(WHITE)

    title = FONT.render("Heap Visualiser - Insert and Extract Min", True, BLACK)
    screen.blit(title, (220, 30))

    info = FONT.render(message, True, BLACK)
    screen.blit(info, (80, 530))

    insert_button = pygame.Rect(130, 470, 120, 40)
    extract_button = pygame.Rect(290, 470, 140, 40)
    reset_button = pygame.Rect(470, 470, 120, 40)
    back_button = pygame.Rect(630, 470, 100, 40)

    draw_button(screen, "Insert", insert_button)
    draw_button(screen, "Extract", extract_button)
    draw_button(screen, "Reset", reset_button)
    draw_button(screen, "Back", back_button)

    for i in range(len(heap)):
        left_child = 2 * i + 1
        right_child = 2 * i + 2

        x1, y1 = get_node_position(i)

        if left_child < len(heap):
            x2, y2 = get_node_position(left_child)
            pygame.draw.line(screen, BLACK, (x1, y1), (x2, y2), 3)

        if right_child < len(heap):
            x2, y2 = get_node_position(right_child)
            pygame.draw.line(screen, BLACK, (x1, y1), (x2, y2), 3)

    for i, value in enumerate(heap):
        x, y = get_node_position(i)

        color = BLUE

        if i == highlighted_index:
            color = RED

        pygame.draw.circle(screen, color, (x, y), 25)
        pygame.draw.circle(screen, BLACK, (x, y), 25, 2)

        text = FONT.render(str(value), True, BLACK)
        text_rect = text.get_rect(center=(x, y))
        screen.blit(text, text_rect)

    heap_text = FONT.render("Heap array: " + str(heap), True, BLACK)
    screen.blit(heap_text, (80, 80))

    pygame.display.flip()

    return insert_button, extract_button, reset_button, back_button


def animate_insert(screen, heap, value):
    heapq.heappush(heap, value)
    index = heap.index(value)

    draw_heap(screen, heap, "Inserted " + str(value), highlighted_index=index)
    pygame.time.wait(600)

    draw_heap(screen, heap, "Heap property restored after insertion")


def animate_extract(screen, heap):
    if not heap:
        draw_heap(screen, heap, "Heap is empty")
        pygame.time.wait(600)
        return None

    removed = heap[0]

    draw_heap(screen, heap, "Extracting minimum value: " + str(removed), highlighted_index=0)
    pygame.time.wait(700)

    heapq.heappop(heap)

    draw_heap(screen, heap, "Extracted " + str(removed) + ". Heap property restored.")
    pygame.time.wait(700)

    return removed


def run(screen):
    global FONT

    FONT = pygame.font.SysFont(None, 26)

    heap = []
    values_to_insert = [50, 30, 70, 20, 40, 60, 10, 80, 25]
    index = 0

    message = "Click Insert to add values. Click Extract to remove min."
    running = True

    while running:
        insert_button, extract_button, reset_button, back_button = draw_heap(
            screen,
            heap,
            message
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                if insert_button.collidepoint(pos):
                    if index < len(values_to_insert):
                        value = values_to_insert[index]
                        animate_insert(screen, heap, value)
                        message = "Inserted " + str(value)
                        index += 1
                    else:
                        message = "No more sample values to insert"

                elif extract_button.collidepoint(pos):
                    removed = animate_extract(screen, heap)

                    if removed is not None:
                        message = "Extracted minimum value: " + str(removed)
                    else:
                        message = "Heap is empty"

                elif reset_button.collidepoint(pos):
                    heap.clear()
                    index = 0
                    message = "Heap reset"

                elif back_button.collidepoint(pos):
                    running = False

        clock.tick(30)