import pygame
import sys
import heapq
import math
import random

WIDTH, HEIGHT = 900, 620
clock = pygame.time.Clock()


# ============================================================
# PATHFINDING PUZZLE  (Dijkstra / A*)
# ============================================================
GRID_ROWS = 18
GRID_COLS = 22
CELL_SIZE = 30
GRID_X = 20
GRID_Y = 60


def pathfinding_puzzle(screen, font, small_font):
    grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]  # 0=open, 1=wall
    start = (0, 0)
    end = (GRID_ROWS - 1, GRID_COLS - 1)
    path = []
    visited_cells = set()
    mode = "wall"   # wall / start / end
    message = "Draw walls | S: set start | E: set end | SPACE: run A* | R: reset | ESC: back"

    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def astar(grid, start, end):
        open_set = []
        heapq.heappush(open_set, (0, start))
        came_from = {}
        g_score = {start: 0}
        visited = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == end:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return list(reversed(path)), visited
            visited.add(current)
            r, c = current
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < GRID_ROWS and 0 <= nc < GRID_COLS and grid[nr][nc] == 0:
                    neighbor = (nr, nc)
                    tentative = g_score[current] + 1
                    if neighbor not in g_score or tentative < g_score[neighbor]:
                        g_score[neighbor] = tentative
                        f = tentative + heuristic(neighbor, end)
                        heapq.heappush(open_set, (f, neighbor))
                        came_from[neighbor] = current
        return [], visited

    def draw_grid():
        screen.fill((30, 30, 30))
        t = font.render("Pathfinding Puzzle (A*)", True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))
        m = small_font.render(message, True, (180, 180, 180))
        screen.blit(m, (10, HEIGHT - 25))

        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                x = GRID_X + c * CELL_SIZE
                y = GRID_Y + r * CELL_SIZE
                cell = (r, c)
                if cell == start:
                    color = (80, 200, 80)
                elif cell == end:
                    color = (200, 80, 80)
                elif cell in path:
                    color = (255, 220, 50)
                elif cell in visited_cells:
                    color = (100, 100, 200)
                elif grid[r][c] == 1:
                    color = (60, 60, 60)
                else:
                    color = (200, 200, 200)
                pygame.draw.rect(screen, color, (x, y, CELL_SIZE - 1, CELL_SIZE - 1))

        # Legend
        legend = [
            ((80, 200, 80), "Start"),
            ((200, 80, 80), "End"),
            ((60, 60, 60), "Wall"),
            ((100, 100, 200), "Visited"),
            ((255, 220, 50), "Path"),
        ]
        lx = GRID_X + GRID_COLS * CELL_SIZE + 15
        for i, (c, label) in enumerate(legend):
            pygame.draw.rect(screen, c, (lx, 80 + i * 28, 20, 20))
            lt = small_font.render(label, True, (220, 220, 220))
            screen.blit(lt, (lx + 26, 82 + i * 28))

        pygame.display.flip()

    running = True
    mouse_held = False

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_r:
                    grid = [[0] * GRID_COLS for _ in range(GRID_ROWS)]
                    path = []
                    visited_cells = set()
                    message = "Grid reset."
                elif event.key == pygame.K_s:
                    mode = "start"
                    message = "Click to place start"
                elif event.key == pygame.K_e:
                    mode = "end"
                    message = "Click to place end"
                elif event.key == pygame.K_w:
                    mode = "wall"
                    message = "Draw walls"
                elif event.key == pygame.K_SPACE:
                    path_result, vis = astar(grid, start, end)
                    visited_cells = vis
                    if path_result:
                        path = set(path_result)
                        message = f"Path found! Length: {len(path_result)}"
                    else:
                        path = set()
                        message = "No path found!"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_held = True
            elif event.type == pygame.MOUSEBUTTONUP:
                mouse_held = False

        if mouse_held:
            mx, my = pygame.mouse.get_pos()
            c = (mx - GRID_X) // CELL_SIZE
            r = (my - GRID_Y) // CELL_SIZE
            if 0 <= r < GRID_ROWS and 0 <= c < GRID_COLS:
                if mode == "wall":
                    grid[r][c] = 1
                    path = []
                    visited_cells = set()
                elif mode == "start":
                    start = (r, c)
                    mode = "wall"
                    message = "Draw walls | SPACE: run A*"
                elif mode == "end":
                    end = (r, c)
                    mode = "wall"
                    message = "Draw walls | SPACE: run A*"

        draw_grid()
        clock.tick(30)


# ============================================================
# EVENT QUEUE SIMULATOR
# ============================================================
def event_queue_simulator(screen, font, small_font):
    heap = []  # (priority, description)
    counter = [0]
    event_names = [
        "Send Email", "Print Document", "Run Backup",
        "Send Notification", "Deploy Update", "Generate Report",
        "Sync Data", "Archive Logs", "Process Payment", "Restart Service"
    ]
    popped_event = None
    running = True

    def add_random_event():
        prio = random.randint(1, 10)
        name = random.choice(event_names)
        counter[0] += 1
        heapq.heappush(heap, (prio, f"{name} #{counter[0]}"))

    def draw_state():
        screen.fill((30, 30, 30))
        t = font.render("Event Queue Simulator (Priority Queue)", True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))

        hint = small_font.render("A: Add event | P: Process (pop) | ESC: back", True, (140, 140, 140))
        screen.blit(hint, (10, HEIGHT - 25))

        # Heap tree
        if heap:
            node_positions = []
            for i in range(len(heap)):
                level = int(math.floor(math.log2(i + 1)))
                idx_in_level = i - (2 ** level - 1)
                gap = 600 // (2 ** level + 1)
                x = 20 + gap * (idx_in_level + 1)
                y = 65 + level * 90
                node_positions.append((x, y))

            for i in range(len(heap)):
                left = 2 * i + 1
                right = 2 * i + 2
                if left < len(heap):
                    pygame.draw.line(screen, (120, 120, 120), node_positions[i], node_positions[left], 2)
                if right < len(heap):
                    pygame.draw.line(screen, (120, 120, 120), node_positions[i], node_positions[right], 2)

            for i, (prio, desc) in enumerate(heap):
                x, y = node_positions[i]
                color = (255, 80, 80) if i == 0 else (255, 165, 0)
                pygame.draw.circle(screen, color, (x, y), 28)
                pygame.draw.circle(screen, (255, 255, 255), (x, y), 28, 2)
                pt = small_font.render(str(prio), True, (0, 0, 0))
                screen.blit(pt, (x - pt.get_width() // 2, y - pt.get_height() // 2))

        # Upcoming events list on right
        list_x = 660
        list_y = 60
        lbl = font.render("Queue (sorted):", True, (220, 220, 100))
        screen.blit(lbl, (list_x, list_y))
        sorted_events = sorted(heap)
        for i, (prio, desc) in enumerate(sorted_events[:8]):
            col = (255, 200, 80) if i == 0 else (180, 180, 180)
            et = small_font.render(f"[{prio}] {desc[:18]}", True, col)
            screen.blit(et, (list_x, list_y + 30 + i * 26))

        # Popped event
        if popped_event:
            pe = font.render(f"Processing: {popped_event[1]}", True, (100, 255, 100))
            screen.blit(pe, (10, HEIGHT - 55))

        pygame.display.flip()

    # Pre-add some events
    for _ in range(5):
        add_random_event()

    while running:
        draw_state()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_a:
                    add_random_event()
                elif event.key == pygame.K_p:
                    if heap:
                        popped_event = heapq.heappop(heap)
                    else:
                        popped_event = None
        clock.tick(30)


# ============================================================
# DYNAMIC PROGRAMMING GRID PUZZLE
# ============================================================
DP_ROWS = 7
DP_COLS = 8
DP_CELL = 70
DP_X = 20
DP_Y = 60


def dp_grid_puzzle(screen, font, small_font):
    obstacles = set()
    dp = [[None] * DP_COLS for _ in range(DP_ROWS)]
    path = []
    mode = "obstacle"
    message = "Click to place obstacle | SPACE: compute | R: reset | ESC: back"
    computed = False

    def compute_dp():
        nonlocal dp, path
        dp = [[None] * DP_COLS for _ in range(DP_ROWS)]
        for r in range(DP_ROWS):
            for c in range(DP_COLS):
                if (r, c) in obstacles:
                    dp[r][c] = 0
                elif r == 0 and c == 0:
                    dp[r][c] = 1
                else:
                    up = dp[r - 1][c] if r > 0 else 0
                    left = dp[r][c - 1] if c > 0 else 0
                    if up is None:
                        up = 0
                    if left is None:
                        left = 0
                    dp[r][c] = up + left

        # Reconstruct path
        path = []
        if dp[DP_ROWS - 1][DP_COLS - 1] and dp[DP_ROWS - 1][DP_COLS - 1] > 0:
            r, c = DP_ROWS - 1, DP_COLS - 1
            path.append((r, c))
            while r > 0 or c > 0:
                up = dp[r - 1][c] if r > 0 and dp[r - 1][c] else 0
                left = dp[r][c - 1] if c > 0 and dp[r][c - 1] else 0
                if up >= left and r > 0:
                    r -= 1
                elif c > 0:
                    c -= 1
                else:
                    break
                path.append((r, c))

    def draw_state():
        screen.fill((30, 30, 30))
        t = font.render("DP Grid Path Puzzle", True, (255, 220, 50))
        screen.blit(t, (WIDTH // 2 - t.get_width() // 2, 10))
        m = small_font.render(message, True, (180, 180, 180))
        screen.blit(m, (10, HEIGHT - 25))

        for r in range(DP_ROWS):
            for c in range(DP_COLS):
                x = DP_X + c * DP_CELL
                y = DP_Y + r * DP_CELL
                cell = (r, c)
                if cell in obstacles:
                    color = (60, 60, 60)
                elif cell == (0, 0):
                    color = (80, 200, 80)
                elif cell == (DP_ROWS - 1, DP_COLS - 1):
                    color = (200, 80, 80)
                elif cell in path:
                    color = (255, 220, 50)
                else:
                    color = (200, 200, 220)

                pygame.draw.rect(screen, color, (x, y, DP_CELL - 2, DP_CELL - 2), border_radius=4)
                pygame.draw.rect(screen, (100, 100, 120), (x, y, DP_CELL - 2, DP_CELL - 2), 1, border_radius=4)

                if dp[r][c] is not None and (r, c) not in obstacles:
                    val_color = (0, 0, 0) if (r, c) not in path else (50, 50, 50)
                    vt = small_font.render(str(dp[r][c]), True, val_color)
                    screen.blit(vt, (x + DP_CELL // 2 - vt.get_width() // 2,
                                     y + DP_CELL // 2 - vt.get_height() // 2))

        # Result
        if computed and dp[DP_ROWS - 1][DP_COLS - 1] is not None:
            total = dp[DP_ROWS - 1][DP_COLS - 1]
            rt = font.render(f"Total paths: {total}", True, (100, 255, 100))
            screen.blit(rt, (DP_X + DP_COLS * DP_CELL + 10, 80))

        pygame.display.flip()

    running = True
    mouse_held = False

    while running:
        draw_state()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    compute_dp()
                    computed = True
                    total = dp[DP_ROWS - 1][DP_COLS - 1] or 0
                    message = f"Paths: {total} | Click: obstacle | SPACE: recompute | R: reset"
                elif event.key == pygame.K_r:
                    obstacles.clear()
                    dp = [[None] * DP_COLS for _ in range(DP_ROWS)]
                    path = []
                    computed = False
                    message = "Click to place obstacle | SPACE: compute | R: reset | ESC: back"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_held = True
            elif event.type == pygame.MOUSEBUTTONUP:
                mouse_held = False

        if mouse_held:
            mx, my = pygame.mouse.get_pos()
            c = (mx - DP_X) // DP_CELL
            r = (my - DP_Y) // DP_CELL
            if 0 <= r < DP_ROWS and 0 <= c < DP_COLS:
                cell = (r, c)
                if cell not in {(0, 0), (DP_ROWS - 1, DP_COLS - 1)}:
                    if cell in obstacles:
                        obstacles.discard(cell)
                    else:
                        obstacles.add(cell)
                    computed = False
                    path = []

        clock.tick(30)


# ============================================================
# PHASE 3 MENU
# ============================================================
def run(screen):
    font = pygame.font.SysFont(None, 32)
    small_font = pygame.font.SysFont(None, 22)

    menu_items = [
        ("Pathfinding Puzzle (A*)", pathfinding_puzzle),
        ("Event Queue Simulator", event_queue_simulator),
        ("DP Grid Path Puzzle", dp_grid_puzzle),
        ("Back to Main Menu", None),
    ]
    selected = 0

    while True:
        screen.fill((40, 40, 60))
        title = font.render("Phase 3: Puzzle Challenges", True, (255, 220, 50))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))

        for i, (label, _) in enumerate(menu_items):
            color = (255, 200, 50) if i == selected else (200, 200, 200)
            rect = pygame.Rect(WIDTH // 2 - 200, 130 + i * 90, 400, 60)
            pygame.draw.rect(screen, (70, 70, 100) if i != selected else (90, 90, 140), rect, border_radius=8)
            pygame.draw.rect(screen, color, rect, 2, border_radius=8)
            txt = font.render(label, True, color)
            screen.blit(txt, (rect.x + rect.width // 2 - txt.get_width() // 2,
                               rect.y + rect.height // 2 - txt.get_height() // 2))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(menu_items)
                elif event.key == pygame.K_UP:
                    selected = (selected - 1) % len(menu_items)
                elif event.key == pygame.K_RETURN:
                    label, func = menu_items[selected]
                    if func is None:
                        return
                    func(screen, font, small_font)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for i, (label, func) in enumerate(menu_items):
                    rect = pygame.Rect(WIDTH // 2 - 200, 130 + i * 90, 400, 60)
                    if rect.collidepoint(pos):
                        if func is None:
                            return
                        func(screen, font, small_font)

        clock.tick(30)
