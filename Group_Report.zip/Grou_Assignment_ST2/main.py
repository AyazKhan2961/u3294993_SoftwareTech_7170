import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 900, 620
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser")

FONT = pygame.font.SysFont(None, 36)
SMALL_FONT = pygame.font.SysFont(None, 24)
clock = pygame.time.Clock()

from modules import phase1_visualiser, phase2_visualiser, phase3_puzzles


def draw_text(text, pos, color=(0, 0, 0), font=None):
    f = font if font else FONT
    txt = f.render(text, True, color)
    screen.blit(txt, pos)


def main_menu():
    screen.fill((40, 40, 70))

    # Title
    title_font = pygame.font.SysFont(None, 52)
    title = title_font.render("DSA Explorer and Visualiser", True, (255, 220, 50))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 40))

    sub = SMALL_FONT.render("University of Canberra  |  Software Technology 2  |  Group Project", True, (180, 180, 200))
    screen.blit(sub, (WIDTH // 2 - sub.get_width() // 2, 95))

    buttons = {
        'Phase 1: Data Structures': pygame.Rect(WIDTH // 2 - 220, 160, 440, 60),
        'Phase 2: Algorithm Visualiser': pygame.Rect(WIDTH // 2 - 220, 250, 440, 60),
        'Phase 3: Puzzle Challenges': pygame.Rect(WIDTH // 2 - 220, 340, 440, 60),
        'Exit': pygame.Rect(WIDTH // 2 - 220, 430, 440, 60),
    }

    descriptions = {
        'Phase 1: Data Structures': 'Stack, Queue, Linked List, BST',
        'Phase 2: Algorithm Visualiser': 'Sorting, Graph BFS/DFS, Heap',
        'Phase 3: Puzzle Challenges': 'Pathfinding (A*), Event Queue, DP Grid',
        'Exit': '',
    }

    colors = {
        'Phase 1: Data Structures': (70, 100, 160),
        'Phase 2: Algorithm Visualiser': (70, 140, 100),
        'Phase 3: Puzzle Challenges': (140, 80, 100),
        'Exit': (80, 80, 90),
    }

    mouse_pos = pygame.mouse.get_pos()

    for text, rect in buttons.items():
        hover = rect.collidepoint(mouse_pos)
        base_color = colors[text]
        draw_color = tuple(min(c + 30, 255) for c in base_color) if hover else base_color
        pygame.draw.rect(screen, draw_color, rect, border_radius=10)
        pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=10)

        label = FONT.render(text, True, (255, 255, 255))
        screen.blit(label, (rect.x + rect.width // 2 - label.get_width() // 2,
                             rect.y + 10))

        if descriptions[text]:
            desc = SMALL_FONT.render(descriptions[text], True, (200, 220, 255))
            screen.blit(desc, (rect.x + rect.width // 2 - desc.get_width() // 2,
                                rect.y + 36))

    # Controls hint at bottom
    hint = SMALL_FONT.render("Use mouse to click or arrow keys + ENTER to navigate each module", True, (140, 140, 160))
    screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, HEIGHT - 30))

    pygame.display.flip()
    return buttons


def main():
    running = True
    current_module = None

    while running:
        buttons = main_menu()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos
                for name, rect in buttons.items():
                    if rect.collidepoint(pos):
                        if name == 'Exit':
                            running = False
                        elif name == 'Phase 1: Data Structures':
                            phase1_visualiser.run(screen)
                        elif name == 'Phase 2: Algorithm Visualiser':
                            phase2_visualiser.run(screen)
                        elif name == 'Phase 3: Puzzle Challenges':
                            phase3_puzzles.run(screen)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
