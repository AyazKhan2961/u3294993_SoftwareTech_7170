Couldnt find the issue related to heap visualiser in phase 2 which caued it to not show hints.
The hints are:

I: insert random

E: Extract-Min