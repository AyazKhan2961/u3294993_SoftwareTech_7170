#===graph_tester.py===
from graph import Graph 
#Basic undirected graph tests
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')


g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

print("Undirected graph:")
g.print_graph()
print()

# Directed graph tests
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

print("Directed graph:")
g.print_graph()
print()


# Weighted graph tests
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 20)

print("Weighted directed graph:")
g.print_graph()

# Weighted graph tests
g = Graph(weighted=True, directed=False)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')


g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 20)

print("Weighted undirected graph:")
g.print_graph()

# Removal tests
print()
print("Removal test")
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')

removal_test.print_graph()

removal_test.remove_edge('A', 'B')

removal_test.print_graph()

removal_test.remove_vertex('C')


removal_test.print_graph()
print()

#Task 2

# BFS on the graph from Activity 1
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

#Task 3: DFS on the same graph
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

#Task 4: Cycle detection in undirected graphs

# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())
