class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if not self.directed:
                self.graph[vertex2].remove(vertex1)

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

    def print_graph(self):
        for vertex in self.graph:
            edges = self.graph[vertex]
            if self.weighted:
                edge_info = [(nbr, self.weights.get((vertex, nbr), 0)) for nbr in edges]
                print(f"{vertex}: {edge_info}")
            else:
                print(f"{vertex}: {edges}")



#Task 2 BFS implementation
    def bfs(self, start):
        visited = []
        queue = [start]
        seen = set([start])
        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)
            for neighbour in self.graph[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        return visited
    

# Task 3 Depth-First Search (DFS) implementation
    def dfs(self, start, visited=None):
        if visited is None:
            visited = set()
        visited.add(start)
        for neighbour in self.graph[start]:
            if neighbour not in visited:
                self.dfs(neighbour, visited)
        return visited  
    
